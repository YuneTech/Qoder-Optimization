---
name: qoder-optimization-share-package
description: 桌面《Qoder 优化》分享包的组成与维护：可分享版规则文档 + 个人规则提示词 + 记忆导出包；真源在 ~/.qoder{,-cn}，文档需跟随真源同步
metadata:
  type: reference
---

桌面分享包目录（名称带版本号，每轮实质更新自动递增；当前在 5.x 线）→ 5.0 / 5.1 → **5.3.1（对方演进版，回发）→ 5.4（2026-10-12，以 5.3.1 为基线并入本机后重打）→ 5.4.1（2026-10-13，office-docs 技能 bug 修复）→ 5.4.2（2026-10-13，office-docs 补「插入表格」链路）→ **5.4.3（2026-10-14，cua 升级 + 备份保留策略 + 规则审阅落实）→ 5.4.4（2026-10-14，磁盘「清理+迁移」触发面补齐 + 五处漂移修复）**——`Qoder-AI编码通用规则.md`（可分享版，脱敏改写）+ `Qoder-个人规则生成提示词.md` + `qoder-memory-export-*.tar.gz`（通用记忆示例包）+ `skills/`（自建技能，`pack-share-extras.js` 打入）+ `mcp/`（MCP 配置模板：占位符版、无凭据）+ `scripts/`（机制脚本白名单）+ `commands/`；改版前在同级留 `_backup-<日期>-*/`。

**5.6.1 打包实录（2026-10-27，任务检查强化 + 守卫误拦修复）**：
- 基线 `Qoder 优化 5.6.0` 复制为 5.6.1；5.6.0 目录与 zip 留回滚点。变更：R9 主张-证据核对 / R3 改动面驱动 / R2 真实备选口径（与六项例外对齐）/ 同类连败计数（attempt-lock 三件套）/ 返回侧体积（tool-payload）/ 大输出自动限流 / 图片体积；memory-first 只认可执行位（heredoc 与引号内引用不算动手）、win-path 不再把 `description:\s` 当盘符、备份口径收窄为"无版本控制兜底的覆盖式改动"、CUA 路由把 computer-use 标为备用面。
- 打包侧：`pack-share-extras.js` 的 `SCRIPT_FILES` 补 5 个新脚本 + `win-path-guard.js`/test（之前从未随包，本地接线却在用）；`SCRIPT_SANITIZE` 给 win-path 加两条宽替换（把说明文字里的用户目录样例统一换成 proj 形态，判据语义不变）；包内 `hooks.example.json` 与 `README-hooks.md` 原计划补 attempt-lock / tool-payload / win-path 三处接线，**实际当时没落进模板**（2026-10-27 内容优化时才补齐，见下节）；两份 md 版本改 5.6.1、技能计数 124→128（**基线包 check-share-docs 因该计数过期本就判红——"家用机实际装 N 个"是活体数字，技能库增减必须同批改文档**）。
- 四道验证全 exit=0；包内 40 技能 / 79 脚本 / 2 子智能体 / 2 个 hooks 模板 / 218 文档 / 记忆 100 条（104 文件哈希一致）；`Qoder 优化 5.6.1.zip.sha256` 已生成（`hash  文件名` 两空格格式）。

**5.6.1 内容优化实录（2026-10-27，版本不变）**：
- 清单生成两处缺陷：`pack-share-extras.js` 的 frontmatter 正则只认 `\n`，随包的 local-adaptation 系列是 CRLF → 7 条技能描述解析成空；"非随包且无 `_meta.json`"会落进 `npx skills add '<owner/repo>@…'` 分支，给自建技能编出不存在的社区安装命令（脚本注释早写了"不能编"，代码分支没对齐）。判据：清单零空条目 + 本机专用段不再出现技能名。
- 根目录 `记忆筛选菜单.md` 是 2026-10-11 手工快照：101 条里 30 条文件名已不存在，且与 tar 内 `rules-summary.md`（由 GROUPS 生成、全部命中）重复 → 删除根文件，以 tar 内那份为唯一筛选菜单。
- 包内自相矛盾四处：规则文档同时写 124/26/98 与 128/27/101；hooks 模板缺 `win-path` / `attempt-lock` / `tool-payload` 三处接线却自称"与本机现役接线一致"；安装落点写 `skills/` 与"默认入按需库"冲突；`rules/doc-system.md`、`rules/rule-enforcement.md` 两个文件名已改（`doc-authoring.md`、`agent-engineering.md`）；文末两条重复的「目标与任务归属」合并进「工作方式」。
- 验收：`pack-extras`（自检）+ `check-share-docs` + `pack-folder` + `verify-share-package` 四道 exit=0，另跑 `pack-extras --check` 无漂移；版本仍 5.6.1，sha256 同步更新。

**5.6.1 单端装配修复（2026-10-27，只装一个客户端时不再造另一个目录）**：
- 事实：随包机制几乎全部把状态 / 台账 / 索引用例硬编码到 `~/.qoder`（9 个守卫 + stop-gate/session-budget/rules-reminder + fact-ledger/tmp-sweeper + tier-skills/build-skills-index + pkg-catalog + 两个 shell 同步脚本 + install-mcp），CN-only 机器第一次跑 hook 就会凭空造出 `~/.qoder`。
- 修法：新增 `scripts/client-root.js`，按 HOME 下**实际存在**的一侧解析（`QODER_HOME` 可覆盖；两侧都在时沿用 `.qoder`），`counterpart()` 给比对类脚本返回"另一侧或 null"；20 个脚本 + `fail-streak-core.js` / `mark-suggestions-evolved.cjs` + `install-mcp.cjs` 全部改用它；`sync-global-config.sh` / `sync-memory.sh` 任一方向单端都只报一句并退 0；hooks 模板占位符换成 `<客户端目录>`，README 增「只装了一个客户端（单端装配）」节。
- **判侧不能用 `__dirname`**：本机 `~/.qoder-cn/scripts` 是指向 `~/.qoder/scripts` 的 junction，被 require 的模块 `__dirname` 会被 Node realpath 成实体侧（实测）；`process.argv[1]` 才保留调用侧。但测试靠 HOME 沙箱隔离，所以解析必须以 HOME 为准。
- 判据（能失败）：沙箱 HOME 只放 `.qoder-cn`，跑 pkg-catalog register / tier-skills / rules-reminder / disk-sweeper / 两个同步脚本后 `.qoder` 必须不存在；单点变异把 `QODER = CLIENT_ROOT` 改回硬编码 `.qoder` 后必须造出 `.qoder`（实测通过，20/20 + 变异对照）。本机两侧都在，路径口径不变（周检 / config-doctor / skills-doctor 仍 CLEAN）。


**5.3.1 回流并入 + 5.4 重打实录（2026-10-12）**：
- 入站 5.3.1 包（对方演进版）→ 按技能 `merge-inbound-qoder-package` 六阶段并入本机 → 按 `update-share-package` **以入站 5.3.1 为基线**（不是桌面 5.1）复制为 5.4 版；5.1 与其 zip 留回滚点。
- **入站包的"自检全绿"必须亲手复跑**：5.3.1 的 README 与 `rules-weekly-audit.test.js` 都宣称有"hook 指向不存在脚本"（V18）与"两侧 `scripts/`+`skills/` 目录不对等"（2g/V20）两项判据，**随包 `rules-weekly-audit.js` 并未实现** → 其自带测试实测 2 条红。处置＝在本机 `rules-weekly-audit.js` 补实现：V18 的路径正则**必须含扩展名**（否则 `fs.existsSync` 查的是无扩展名路径、基线误红）；2h 两侧同缺要静默（单端/单能力合法）；同时把测试基线里那条 hook 改成指向**真实存在的桩**。
- **记忆包"已脱敏"自称要实测复验**：5.3.1 记忆包残留个人账号、内网 schema 名、内网服务器路径与代理环境 → 并入本机的条目就地擦除；重建包时补脱敏表。
- **记忆包与本机是"同批主题的另一代导出"**（51 条同名且多分叉 + 约 25 条同主题改了前缀）→ 全量并入既造重复又撞 `MEMORY.md` 25000 字节上限；按用户裁决**只并方法论/工具类 18 条**（硬件/环境类与重命名重复跳过），再压索引回限内。
- **`pack-generic-memory.js` 要一起动的表**：KEEP / GROUPS（索引与摘要由它生成，缺一断言失败）/ SANITIZE，加**新增的 `LINK_UNWRAP_FILES`**（把新条目里指向包外的 `[[链接]]` 降为纯文字，并清家目录字面量）。本轮还修掉 3 处**旧记忆漂移出 SANITIZE 表**（`feedback-clarify-before-acting` 整行失配、`reference-common-mcp-servers` 新增带内网库地址的行、`reference-continuation-hardening` 带项目名）。**教训：新写的记忆正文别带真实标识——脱敏表只覆盖老行，新行会直接把内网信息带进包。**
- **`pack-share-extras.js` 本轮三处扩展**：① `resolveSkillDir` 支持从 `skills-disabled/` 回退（本机停用 5 个重叠技能后仍要随包发源码）；② 新增 `COMMAND_FILES` 白名单（此前不打包 `commands/`，新指令 `/edge-net-check` 会漏）；③ `SKILLS` 扩到 22 并加 `OVERLAP_NOTE`——清单里注明哪 5 个与随包 rules 重叠、收件人可自行去重。
- **`check-share-docs.js` 两条计数硬判据**：文档「N 条领域 / 流程规则」== `~/.qoder/rules/*.md` 实测、yaml 块数相等，且须含"**家用机实际装 N 个**"（正则写死这个短语）；本轮 rules 18 / skills 69，补了 3 个此前未成节的规则块（文档运行时复核 / 外部 jar 实体扩展 / 多 schema 权威源）。
- 四道验证全 exit=0；包内 22 技能 / 2 agents / 3 指令 / 52 脚本 / 128 文档 / 记忆 100 条。本机侧：两侧 `IN-SYNC`、记忆索引自洽、真机周检 0 告警、18 个自测全绿、stop-gate 活体判据真拦。

**5.4.1 打包实录（2026-10-13，office-docs 技能 bug 修复）**：
- 基线 `Qoder 优化 5.4` 复制为 `Qoder 优化 5.4.1`；5.4 留回滚点。变更：`skills/office-docs/scripts/office.js` 的 `arr()` 函数修复裸空元素（如 `<w:p/>`）解析为空字符串时触发 runText 递归栈溢出的 bug（`arr('')` 从 `['']` 改为 `[]`）。
- **`.bak` 备份文件不进包**：`pack-share-extras.js` 复制技能目录时会把 `.bak_*` 一起带入 → 打包后手动删除并重跑 `pack-folder`；下一版应在 `pack-share-extras.js` 的 `copyDir` 里加过滤（本轮未做，临时处置）。
- 四道验证全 exit=0；包内 22 技能 / 130 文档 / 记忆 100 条（104 文件哈希比对一致）。

**5.4.2 打包实录（2026-10-13，office-docs 补「插入表格」链路）**：
- 基线 `Qoder 优化 5.4.1` 复制为 `Qoder 优化 5.4.2`；5.4.1 留回滚点。变更：`office-docs` 的 SKILL.md 新增「往既有 docx 模板插入新表格（保模板样式）」专节 + description 补触发词 + 「已知边界」加裸空标签条目（`office.js` 的 `arr()` 修复随 5.4.1 已入包）；两份文档同步（通用规则 md 加本版条目与办公文档 capsule 描述）。
- **被导出记忆的新行要过敏感词形态**：5.4.1 实录段里的无空格包名形态不在 SANITIZE 覆盖内 → 记忆包自检判红（敏感词），本轮改写为带空格形态「Qoder 优化」后通过——新写正文先自查，别等打包才踩。
- **5.4.1 留的「copyDir 加过滤」本轮已做，但要覆盖下划线命名**：`pack-share-extras.js` `copyDir`、`check-share-docs.js` ⑦、`pack-folder.js` 三处的 `SKIP_PAT` 原为 `([-.][^/]*)?`，只认 `-` / `.` 分隔——`.bak_20261013` 这类下划线备份照样漏进包（实测先在包内发现才定位到）；三处字符类都补成 `[-._]`。过滤生效的判据：删掉包内遗留 `.bak_` 后重跑 extras，文件**不再重现**（实测通过）。
- 四道验证全 exit=0；包内 22 技能（62 文件）/ 52 脚本 / 2 子智能体 / 记忆 100 条（哈希比对一致）。
- **旧版不一定留在桌面**：本轮打包期间（16:35），上一版 `Qoder 优化 5.4` / `5.4.1` 目录与两个旧 zip 被清入回收站（非打包链路所为——链路脚本无回收 / 删除兄弟目录逻辑，且普通 rm 进不了回收站）；查历史，各轮旧版最终都进了回收站。**回滚点实际在回收站**：要旧版时先从回收站还原，别以为桌面目录还在。

**5.4.3 打包实录（2026-10-14，cua 升级 + 备份保留策略 + 规则审阅落实）**：
- 基线 `Qoder 优化 5.4.2` 复制为 `Qoder 优化 5.4.3`。变更批次：① cua 守卫扩到 0.35.2 新工具（`run_steps`/`run_script` 的 7 种形态，自测 35→50）+ 还原两跳兜底（沉降复读 + user32）；② 新机制脚本 `backup-file.js`（备份保留策略：≤3 份 / 删 7 天前 / 至少 1 份、删除进回收站；`edit-guard` 文案改指它）；③ 规则"裁决弹窗口径"实测化（**删掉 120 秒承诺**，改"未答复：常规按推荐继续 / gated 未授权"——同步 5 处载体：AGENTS / reminder hook / stop-gate 文案 / clean-disk / clean-temp）+ 工具条目去重 + 自动更新纪律 + 停手例外收窄；④ 周检新增 2i"有新版未升"（V21/V21b 自测）；⑤ 合并技能加「合并后审阅」阶段。通用规则 md 同步 8 处（含 changelog 5.4.3 条目）。
- **记忆瘦身批次必须与包脚本同批改**：5 条记忆瘦成"指针 + Why/案例"后立刻踩两个坑——`SANITIZE` 的旧行失配（pop-decision 3 条替换规则整块删除 + commit 注释）、瘦身后 `[[链接]]` 指向包外（该文件加进 `LINK_UNWRAP_FILES`）；先把 `pack-generic-memory.js` 跑到新暂存目录自检全绿，再 tar、再验。
- 四道验证全 exit=0；包内 22 技能 / 54 脚本 / 132 文档 / 记忆 100 条（哈希比对一致）。

**5.4.4 打包实录（2026-10-14，磁盘「清理+迁移」触发面补齐 + 五处漂移修复）**：
- 起因：用户复核"涉及 C 盘的迁移询问"规则——真源在（`AGENTS.md` 两条：清理与迁移一起问 / 首次分享包必问迁移），但**三个消费面只留"清理两问"**：`/clean-disk` 步骤、SessionStart 磁盘哨兵注入、分享文档；触发面也缺"任何要向 C 盘写大体积数据的操作"。
- 修复：① 三消费面并入"迁移一问"（clean-disk 第三问 / disk-sweeper 输出脚注 / session-budget 哨兵文案 / 文档同节）；② AGENTS 触发面补"向 C 盘写大数据操作（低于 10GB 并入弹窗）+ 分享包首次部署不看水位也问迁移"。
- **顺带全库漂移扫描又抓到 5 处**（用户点名"顺便检查"）：rules-reminder 六项例外旧措辞、disk-sweeper "两问"残留、周检磁盘建议文案、迁移技能"一次问两问"、个人规则提示词旧工具条目——全部修正。命中 `file-history/` 的旧文属历史快照，不算漂移。
- **教训**：同一句规则被多个消费面复述时，改一处必须全仓复查；"两问"这类编号词各载体含义不同（sweeper＝一档+三档；迁移技能＝清理组+迁移组），统一成"**一次问全（清理两问 + 迁移一问）**"后歧义消除。可复用命令：`grep -rln "<旧短语>" ~/.qoder | grep -v "file-history\|\.bak"`。
- 四道验证全 exit=0；包内 22 技能 / 54 脚本 / 132 文档 / 记忆 100 条。

**升版是「复制旧目录」，白名单缩了 / 脚本改名后旧文件会留在包里继续教人做错事**（2026-09-30 实测：4.10 基线里还带着已被判为有害的 `sync-byok-modelconfigs.js`）。修法在 `pack-share-extras.js`：拷完白名单后按 `SCRIPT_FILES` / `SKILLS` 剪掉输出目录里不在名单的文件并打印 `[剪除] …`，别靠手工删——下一版还会漏。

**5.0 打包实录（2026-10-08）**：
- 基线取自上一版包目录（先例：由并行会话产出的 4.10 线）→ 复制为新版目录（用户指定版本号）；旧目录与 zip 留作回滚点。
- `pack-share-extras.js` 本轮新增两样产出：`agents/`（用户级子智能体，白名单 `runtime-truth-verifier` / `deploy-verifier`）与 `plugins/README-plugins.md`（**插件不转发源码**，只给"装哪些 / 为什么 / settings.json 怎么写"，含"本机禁用"项与理由）。两者都进了产物敏感词扫描范围与包根 README 表。
- 文档同步仍用"节尾追加"法，但**必须加后置断言**：本轮因 `String.replace` 的 `$` 模式（替换文本里出现 `` $` ``）把 47k 字符的文档一次放大到 128k（同一节出现 3 次）——**修法是函数式替换 `replace(锚点, () => 文本)`**，并断言"目标节只出现 1 次 + 体积增幅有界 + yaml 块数 = 规则数"。教训已进 `rules/text-edit-safety.md` 与技能 `safe-text-editing`。
- 四道验证全 exit=0；包内 14 个自制技能 / 2 agents / 1 插件清单 / 45 脚本 / 88 文档 / 记忆 78 条。

**5.1 打包实录（2026-10-08，AGENTS.md 新增加「问题回写既有内容」规则同批）**：
- 基线 `Qoder 优化 5.0` 复制为 `Qoder 优化 5.1`；5.0 与 4.10 留回滚点。变更：AGENTS.md 新增回写纪律 + 记忆 `feedback-auto-supplement-rules.md` 增「回写既有内容」小节 + 两份文档同步该条。
- **坑 1（改 KEEP 内记忆必读）**：记忆正文里引用**真实项目名**会让 `pack-generic-memory.js` 敏感词自检 exit 1（本轮直接卡包）——记忆写 Why 时用"某遗留系统"这类通用表述，别带项目名/内网词；**新写的行不在脱敏表覆盖内**，要么写成"Qoder 优化"（带空格）这类不过敏的形态，要么同步补进脚本的 SANITIZE 表。
- **坑 2**：`verify-share-package.js` 第二参数要传「**只含一个顶层导出目录的父目录**」（脚本内部 `readdirSync(STAGE)[0]` 拼路径）——直接传导出目录本身会 ENOTDIR 崩溃；父目录里混了别的文件会取错条目。稳妥做法：临时建 `pack-parent/` 只放导出目录。
- **坑 3**：`pack-share-extras.js` **不重打 zip**——正确顺序是 `pack-folder（首次可省）→ pack-extras → **重跑 pack-folder** → check-share-docs → verify-share-package`；否则 zip 落后于目录一步（本轮在 extras 后补跑 pack-folder 才一致）。技能 `update-share-package` 步骤说明已同步此注。
- 四道验证全 exit=0；包内 14 技能 / 88 文档 / 记忆 81 条（85 文件哈希比对一致）。

**⚠️ 4.3 起新增的一条硬教训（改记忆的人必读）**：`pack-generic-memory.js` 的 `SANITIZE` 表按**整行字面量**匹配记忆正文，**记忆正文一改，对应条目立刻失配** → 自检报 `[未命中]`、exit 1、包打不出来（本轮降量改了 `reference-qoder-global-setup.md` 的三行，三条 SANITIZE 全断，连带该行里的包名/内部项目名裸奔到敏感词自检）。规矩：**改被脱敏改写的记忆后，同批更新 SANITIZE 表，且源串要从记忆文件里程序化提取（别手抄）**；新增记忆进 `KEEP` 时要同时补 `GROUPS`（索引由 GROUPS 生成，缺一即断言失败），并在 SANITIZE 里把它指向包外的 `[[链接]]` 收成纯文字。

**4.3 打包链路实录（2026-09-29）**：
- 旧版本可能只剩 zip、源目录已不在：以 `unzip` 解旧 zip 为新版目录（旧 zip 保留作回滚点）；**解包后内层顶层目录要改名**，`pack-folder.js` 才会打出与新版本号一致的顶层名。
- 文档同步点（`check-share-docs.js` 会逐条判）：① `yaml 块数 == rules/*.md 数`（本轮 12→13，新增 Python 规则块）；② 文档里的「N 条领域 / 流程规则」与「家用机实际装 N 个」必须等于磁盘实测（13 / 55）。
- `pack-share-extras.js` 本轮三处改动：`SKILLS` 白名单新增 3 个自制技能；新增 `NO_SHIP_SELF_BUILT`——**自制但源码里有意保留内网形态样例**的技能（其 selftest 夹具要证明内网 IP 会被门禁抓到，抽掉样例等于削弱自测），清单里如实标「本机专用」、不编社区安装命令；**本机专用技能的 description 不进清单**（描述天然带环境信息，否则会让「清单敏感词」自检失败）。
- 四道验证全 exit=0：`pack-share-extras`（自检：技能齐全 + 产物零敏感词）、`pack-folder`、`check-share-docs`、`verify-share-package`（结构 / 敏感词 / 链接 / 与暂存逐文件哈希）。

**4.1 打包链路实录（2026-09-23；含链路 8 处修复，务必沿用）**：
- 组装：解包 4.0 为新版目录 → 删基线里不该带的（`export-memory.sh` / `import-memory.sh`：含本机凭据清单）→ `pack-share-extras.js` 重建 skills//scripts//mcp//README → 重建记忆包 → tar → zip → 双校验。
- `pack-share-extras.js` 六处修复：① `copyDir` 排除 `node_modules`（此前把整棵依赖树打进包）；② `SCRIPT_FILES` 补 4.0 新脚本（commit-scope-guard / disk-sweeper / global-config-guard.test / **stop-gate.test**——漏它会让未净化文件混入）；③④ `SCRIPT_SANITIZE` 增 rules-weekly-audit.test / stop-gate.test 的用户目录绝对路径示例；⑤ 删 validate-repowiki 的过时替换（4.0 文件已自带脱敏，"未命中即报错"是设计，别留过时条目）；⑥ 扫描豁免 `package-lock.json`（npm registry 哈希的随机 base64 串会撞敏感词清单里的短代号，实测撞过）。
- `verify-share-package.js`：**两处**扫描循环都要同一豁免（包目录扫描 + tar 内记忆包扫描）。
- `pack-generic-memory.js` **不自动建暂存目录**（直接 ENOENT）——先 `mkdir -p` 再跑。
- verify 的"暂存目录"参数要传**含顶层子目录**的路径（tar 阶段目录），不是记忆包平铺目录。
- 文档计数（"家用机实际装 N 个技能"）随磁盘实测更新，否则 `check-share-docs.js` 判红。

**关系**：文档是"分享版改写"，**真源是 `~/.qoder{,-cn}/AGENTS.md` + `rules/*.md`（12 个）**——真源更新后要对照检查文档。2026-09-19 一次合并（18 处）：vibe-coding 整节、三层 hook 机制现状、长任务/frontend/testing/databases/infra-ops/delivery-pr 的条目与 glob、description 关键词、技能名与计数口径（11 条规则 / 80 候选）、rules·memory 不可建链的新事实。

**维护检查清单**（改完必跑，已脚本化为 `~/.qoder/scripts/check-share-docs.js`）：① 所有 ` ```yaml ` 块解析合法且含 trigger（应 12 个）；② 计数口径 = 磁盘实测（12 条领域规则 / 80 候选技能名 / 已装技能数）；③ 旧技能名无残留（nginx-configuration→nginx-config-builder、rabbitmq-development→rabbitmq-expert、kafka-development→kafka-best-practices、db→oracledb 等）；④ 三反引号行数为偶数；⑤ 记忆包由 `pack-generic-memory.js` 重建（自检 exit 0）并解压复验（哈希一致 + 敏感词零命中）才算数——未经复验的 tar 不得随包分发。

相关：[[reference-qoder-global-setup]] [[reference-rule-enforcement-mechanisms]]
