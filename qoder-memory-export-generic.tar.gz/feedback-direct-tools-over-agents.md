---
name: feedback-direct-tools-over-agents
description: 远程排查/搜索类工作优先用直接工具（SSH/curl/浏览器 MCP）亲自执行，不委派子代理
metadata:
  type: feedback
---

做远程排查 / 搜索类工作时，直接用 Bash（SSH/curl 等）和浏览器 MCP 工具亲自操作，不要委派子代理去做搜索类任务。

**Why:** 实测中委派子代理做排查被打断（"接续上面的任务"）；改用直接 SSH/grep + 浏览器排查后效率明显更高。
**How to apply:** 多步远程检索默认自己直接执行；只有真正大型且可并行的独立任务再考虑子代理。
