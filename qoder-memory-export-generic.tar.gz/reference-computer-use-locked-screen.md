---
name: reference-computer-use-locked-screen
description: 锁屏状态下 GUI 自动化必失败：LockApp 持有前台→窗口激活被拒（SetForegroundWindow/AttachThreadInput 全 False）、合成输入进不了安全桌面；判据与规避
metadata:
  type: reference
---

用 computer-use / 原生脚本操作桌面 App 时，**先确认屏幕没锁**——锁屏时所有"点/输入/激活窗口"都会静默失败（2026-09-22 实测，排查了一轮才定位）。

- **现象**：`SetForegroundWindow` 恒返回 False、`AttachThreadInput` 技巧也无效；computer-use 报 `target window could not be made foreground before native input`；点击放出去了但目标窗口毫无反应；PowerShell 里 `GetForegroundWindow()` 一度返回 0。
- **根因**：锁屏时前台窗口属于 **`LockApp.exe`**（`C:\Windows\SystemApps\Microsoft.LockApp*`，在安全桌面），Windows 据此禁止其它进程夺取前台；**合成输入（keybd_event / SendInput / mouse_event）也无法送达安全桌面**，因此**程序化解锁不可行**（键盘输 PIN 也进不去）。
- **定位手法（30 秒）**：枚举顶层窗口不出来的 hwnd，用 `GetWindowThreadProcessId(hwnd, &pid)` 拿 pid → `Get-Process` 看进程名；是 `LockApp` / `LogonUI` 即为锁屏。
- **正确做法**：**请用户解锁后继续**（把阻塞如实标注为"外部条件挡住"，不要硬试）——反复尝试还可能与账号锁定策略冲突；解锁后 `isForeground` 会恢复正常，computer-use 的 UIA 语义点击（`element_index`）与原生点击都能正常工作。
- **另一条通用坑**：第三方启动器（如 uTools）会用一个**隐藏框架窗口**持有前台 → 同样导致目标窗口无法激活；同理先用上面的方法定位归属，必要时临时隐藏该窗口（用完恢复显示）。
- **注意**：解锁 PIN / 口令属凭据红线——只可用于当次操作（如写进临时脚本后立即删除），**不得写入记忆、规则、日志与汇报**。
