---
name: tooling-windows-sandbox-orphan-lock
description: Windows 上 hook 自测脚手架的两个坑：spawnSync timeout 只杀直接子进程（bash sleep 孤儿占住目录 → rmSync ENOTEMPTY / writeFileSync EPERM），沙箱目录必须按 pid 独立；以及 fixture 不镜像真实接线会让新判据在基线假红
metadata:
  type: reference
---

**现象**（2026-09-20 写 `global-config-guard.test.js` 时连撞两次）：
1. 第二轮跑崩在 `Error: ENOTEMPTY: directory not empty, rmdir '~/.gcg-sandbox/.qoder/scripts'`；
2. 加了重试之后又崩在 `EPERM: operation not permitted, open '.../sync-global-config.sh'`（写夹具失败）。

**根因**：`spawnSync(node, ..., {timeout})` 超时**只杀直接子进程**；被它 spawn 出去的 `bash → sleep`
在 Windows 上会**变成孤儿继续跑**，短暂占住沙箱目录。测试用固定目录名 ⇒ 上一轮的孤儿正在锁这一轮的夹具。
（Linux 上 timeout 会连带信号到进程组，所以这类坑只在 Windows 复现。）

**正确做法**：
- 沙箱目录**按进程号独立**：`path.join(os.homedir(), '.xxx-sandbox-' + process.pid)`，别复用固定名；
  开局顺手扫掉 `mtime` 超一小时的同名遗留（自己删不掉的孤儿留给下一轮清）。
- 清理要重试而不是假定成功：`rmSync` 后 `existsSync` 复核，最多 10 次、每次 `Atomics.wait(SharedArrayBuffer, 0,0, 250)` 同步等待
  （测试脚本里不想引入 async，`Atomics.wait` 是最省事的阻塞 sleep）。
- 判据红之前先分清"脚手架没清干净"与"被测物坏了"——这两种红的处置完全相反。

**同轮第二个坑（更值得记）：新判据在基线假红，往往是 fixture 没镜像真实接线。**
给周检加"串行合计 vs hook 超时"检查后，`rules-weekly-audit.test.js` 的**基线用例**立刻红：
它的 fixture 把四个事件的 command 全写成占位 `'x'`，新判据按真名去找 `global-config-guard.js` 的 timeout 找不到。
**修法是把 fixture 补成真实形状**（加一条带真名与 `timeout: 15` 的 SessionStart 接线），
**不是**把判据在"找不到"时降级为静默——那样正好把"消费者根本没挂上"这个真异常也一起吞掉。
**How to apply:** 新增任何"从 settings.json / 配置里读真名"的检查时，同一批改掉沙箱 fixture；
并给"读不到"留一条 warn（它本身就是要防的异常），别留 `continue`。

**新判据假红的第二种成因：比较器语义（2026-09-21 探针里踩到）。**
自写断言助手常见两种签名并存：`check(msg, actual, expected)` 用**严格相等 `===`**，另有 `checkTrue` 判布尔。
把数组/对象字面量当 `expected` 传给 `check` ⇒ 引用不同**必然红**，而失败信息经 `String(expected)` 打成
"期望 （空）"（`String([]) === ''`），**看起来像真缺陷**。
**How to apply:** 新判据第一跑就红，先做三件事再怀疑产品：① 读断言助手的实现（`===` 还是 deepEqual）；
② 集合类期望一律**先 join/序列化再比字符串**（照同文件既有写法，别改助手语义）；
③ 空集合断言必须配"确实抓到了 N 条"的正向前置，否则换成 `checkTrue` 也会假绿。
相关：feedback-checker-crash-vs-red、reference-rule-enforcement-mechanisms。相关：feedback-checker-crash-vs-red、reference-rule-enforcement-mechanisms。
