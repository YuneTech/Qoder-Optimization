---
name: tooling-windows-scheduled-task-cancel
description: Unregister-ScheduledTask 只删存储层，Task Scheduler 服务内的任务镜像仍会按旧触发器再点一次火；取消定时关机必须同时断开动作目标文件
metadata:
  type: reference
---

**现象**：`Unregister-ScheduledTask` 之后三重检查全干净（`Get-ScheduledTask` 查不到、
`C:\Windows\System32\Tasks\<name>` 不存在、按 Action 关键字全库扫描 0 命中），据此回答用户"已取消，明天不会关机"——
**7 小时后事件日志出现该任务的 1074，机器真的按 07:50 关了一次。**

**根因**：删除只作用于任务存储（XML），而 Task Scheduler **服务进程持有已加载的任务镜像**；
服务重载（重启服务/重启机器）前旧触发器仍可能命中一次。**存储层为空 ≠ 调度层已停**。

**正确做法（取消定时动作要两层都断）**
1. `Disable-ScheduledTask` → `Unregister-ScheduledTask`（断存储与后续触发）；
2. **改名或删掉任务所调用的脚本文件**（断残留镜像的执行路径——动作报"文件不存在"才是真哑火）；
3. `shutdown /a` 清掉已进入倒计时的关机。

**三条硬取证（比查配置可靠）**
- `Get-WinEvent -FilterHashtable @{LogName='System'; Id=1074}`：1074 的**备注字段**是唯一标识，
  脚本里 `/c "…"` 的串原样落进日志，一眼分辨哪条自动化发起的（本项目靠它把误判坐实）。
- `shutdown /a` 返回 **1116** = 当前无挂起倒计时；返回 0 = 确实有一个、已被中止。
- 发起进程名区分人机：`shutdown.exe` = 脚本/自动化；`StartMenuExperienceHost.exe` = 人手动点关机；
  `NahimicService.exe` 这类第三方服务也会自行发起重启。

**适用边界**：一切"取消由计划任务/服务承载的定时动作"（关机、重启、备份、同步）按两层收口；
只验过存储层时结论要说"存储层已删、服务缓存未确认"，**不许说"已取消"**。
