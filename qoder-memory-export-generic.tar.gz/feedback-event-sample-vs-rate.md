---
name: feedback-event-sample-vs-rate
description: 事件日志判据必须按 boot/日期分桶计数；从 top-N 抽样读"每次都发生"会把一次性事件当成常态并推出错误修复
metadata:
  type: feedback
---

**用事件日志做判据时，先按"每次开机/每天"分桶计数，再下"反复发生"的结论。** 只取 `Group-Object -First 20` 或 `Select-Object -First 3` 的样本，不足以支撑"每次都报"这类断言。

- **实测（2026-10-07 本机 Windows 完整性体检）**：抽样里看到 `volmgr id=46 故障转储初始化未成功`，我据此写成"每次开机都报，32GB 内存配 8GB 上限页面文件 ⇒ 内核转储永远写不出来"，并给出"改成小内存转储"的推荐。回查全量：**30 天内只有 1 条（10-01 14:29），之后 8 次开机（10-04×5、10-06×3）零复现，90 天 BSOD 记录 = 0**。
- **二次错误**：即使那条是真的，我推荐的改动也是空操作——`CrashDumpEnabled=3` **本来就是"小内存转储"**（微软官方 kb/307973：0 无 / 1 完整 / 2 内核 / 3 小 / 7 自动；WMI `Win32_OSRecoveryConfiguration.DebugInfoType` 读数一致）。推荐前提被自己的文档核对推翻。
- **正确做法**：① 事件类断言写成"ID=X 在 N 次 boot 中出现 M 次"，boot 用 `Kernel-General` ID=12 的时间戳列表算；② 涉及枚举值语义（注册表 DWORD ↔ UI 选项 ↔ WMI 属性）时**先查官方文档或 WMI 的 ValueMap，不凭记忆猜映射**——网上流传两套 CrashDumpEnabled 表，猜错会把配置改坏；③ 否定式与常态式结论都要带分桶计数与时间戳复测。
- **同族陷阱**：服务 `ExitCode=1077` 只说明"本次开机从未启动"，不等于服务坏了（本机 Norton 360 四个 Auto 服务如此，而 Defender 实时防护正常）。要判坏，去找 SCM 7000/7001/7023/7034 的具体报错文本。
- **适用边界**：所有"日志里有没有某类错误"的体检/验收；不适用于单次事件的取证（那条只需时间与文本一致即可）。
- 关联：feedback-checker-crash-vs-red、feedback-fix-and-sweep、`reference-windows-powershell-diagnostics`、`reference-windows-integrity-check-facts`。
