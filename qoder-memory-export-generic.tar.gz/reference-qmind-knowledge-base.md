---
name: reference-qmind-knowledge-base
description: QMind 知识中心使用约定：通用库放跨项目规范、项目一个库；Agent 不能建库/删/改名，按内容哈希去重
metadata:
  type: reference
---

- QMind 知识中心用于沉淀知识：`通用`库放跨项目通用内容（开发标准、协作习惯、方法论），每个项目一个独立库。
- 标题即分类：通用库 `通用 / <分组> / <文档名>`；项目库 `<项目> / wiki / <文件名>`、`<项目> / repowiki / <分类路径>`、`<项目> / knowledge / <卡片>/<条目>`。
- Agent 侧 QMind 工具只有 add_source / list_notebooks / list_sources / get_source / read_source / search / retrieve：
  - **不能新建知识库**；写入未授权的库会报 `permission_denied: notebook is outside the current Agent Notebook scope`，需用户在知识中心建库并授权 Agent。
  - **不能删除或重命名资料**，清理与改名只能在知识中心界面完成。
- 服务端按内容哈希去重：同内容不同标题会被拒（`already_exists`）；更新流程 = 界面删旧 → 再导入新。
- 导入大目录时按文件逐个 add_source（filePath 方式），传目录会报 "The local file could not be read"。
- **text 形态在本环境不可用（2026-09-18 实测）**：`kind:"text"` 连 `title:"test"/content:"test"` 最小用例都返回 `invalid_input`（不可重试）；`kind:"file"` 正常。沉淀文档的可靠流程 = 先把 markdown 落盘到项目目录 → 用 filePath 导入 → `get_source` 确认 ready → `read_source` 抽查正文完整。别再浪费轮次试 text。
