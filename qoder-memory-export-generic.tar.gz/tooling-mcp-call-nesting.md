---
name: tooling-mcp-call-nesting
description: mcp_call 的 toolName 必须是目标全限定名；填成 "mcp_call" 本身或多套一层 arguments 会得到 "No connected MCP server offers a tool named mcp_call"，看着像 MCP 服务挂了其实是用法错
metadata:
  type: reference
---

**现象**（2026-10-08 实测，同一回合连错两次）：想派工给新会话，写成
`mcp_call({ toolName: "mcp_call", arguments: { toolName: "mcp__builtin__create_chat_session", arguments: {...} } })`
⇒ 返回 `Error: No connected MCP server offers a tool named mcp_call.`

**根因**：`mcp_call` 是**元工具**，它的 `toolName` 只能是目标工具的全限定名
（`mcp__<server>__<tool>`），`arguments` 直接就是那个工具自己的参数对象 —— **不能再套一层**。

**正确写法**：
`mcp_call({ toolName: "mcp__builtin__create_chat_session", arguments: { prompt: "..." } })`

**适用边界**：所有走 lazy-loading 元工具的 MCP 调用（`mcp_list` / `mcp_get` / `mcp_call` 三个元工具本身除外）。
报错文案说的是"没有这个工具"，极易被误读成"MCP 服务未连接 / 掉了" ⇒
**先核自己传的 `toolName` 是不是字面量 `mcp_call`，再怀疑服务端**。

**同族形状**：参数该传真结构却塞成 JSON 字符串，会得到 validation failed 或"看起来像用户没答"
（见 feedback-pop-decision-dialog-not-prose 里 `AskUserQuestion.questions` 的同一条坑）。
工具调用**静默失败**比报错更贵：本轮第一次失败后我以为派工已发出，实际什么都没发生。
