---
name: feedback-commit-subject-not-reused
description: 复用上一条 commit 文案时 subject 会跟着被复制，造成两笔提交标题相同；已推送后无法 amend（禁 force push）⇒ 提交前必须逐字核 subject 描述的是本笔
metadata:
  type: feedback
---

写第二笔提交时如果整段复用上一笔的 `git commit -m "$(cat <<'EOF' ... EOF)"` 文案（只改正文），
**subject 行会一起被复制**，结果是同一会话里两笔提交标题完全相同、其中一笔的标题描述的不是它自己的内容。

**Why:** 2026-10-06 同一会话内**连犯两次**：`e7c7e575` 与 `250056af` 标题相同；
`2f1bd56e` 又复制了 `59cbc1ee` 的 B13 标题，而它的正文讲的是"08:3x 扫查轮四处改判"。
两笔都已推送 ⇒ 改标题要 rebase/force push，而"绝不 force push 已推送分支"是硬红线 ⇒ **只能事后认，防不住**。
代价不是美观：`git log --oneline` 是本仓交接文档的入口之一（AGENTS §八 要求"一格一次原子提交，
message 写判据 + 反证 + 坑"），标题重复会让人误判某一笔的内容，等于把交付证据链弄脏。

**How to apply:**
- 每次 `git commit` 前，把 subject 单独读一遍问："这句话描述的**是本笔的 diff** 吗？"
- 复用旧文案时**只复用结构**（判据 / 反证 / 坑 三段），subject 必须重写。
- 提交完立刻跑 `git log --oneline -3`：若出现两行 subject 相同，趁**还没推送**时 `git commit --amend` 改
  （未推送才允许）。已推送的就照实写进汇报，别悄悄留着。
- 相关：feedback-commit-after-changes、feedback-delivery-hygiene
