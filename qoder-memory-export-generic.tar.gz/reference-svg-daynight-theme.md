---
name: reference-svg-daynight-theme
description: SVG 插画做昼夜/主题切换的实现手法：压暗层+光源重绘层的合成顺序、主体用 filter 单独调亮度、过渡只读得到起始值、reduced-motion 只藏动效类控件
metadata:
  type: reference
---

给"一幅已经画好的 SVG 插画"加昼夜（或任何主题）切换时，**不要逐个改元素的填色**（元素多、易漏、白改黑难还原）。用"压暗 + 光源重绘"的合成顺序，实测有效（复古海报风插画动效）：

1. **合成顺序（关键）**：环境美术 → `<rect class="veil">`（盖住天空/海/沙丘/路面，压暗）→ 需要在夜里保持明亮的东西画在 veil **之上**（月亮、星星、标题文字、灯光层）。主题切换就只是若干 `opacity` 的 0↔1。
2. **压暗层用垂直渐变**（顶部更深），比单色 veil 自然；`fill="url(#veil)"` + CSS `opacity` 切换，配合 `transition: opacity .6s` 就有平滑换场。
3. **主体（角色/车）单独调亮度**：给主体组 `filter: brightness(.74)` + `transition: filter`，与环境解耦——环境压得更狠、主体只轻压，才有"被月光照着"的层次，否则整张一起变暗会糊成一片。
4. **光源要重绘在 veil 之上**：头灯/尾灯在主体组里会被一起压暗，必须在夜光层重新画一份亮芯 + 泛光 + 光锥 + 地面光斑；3px 级的车身起伏误差可忽略，不必让灯光层跟着起伏。
5. **两个坑**：
   - 元素加 CSS `filter` 后，其 `<use>` 影子树里的动画**不受影响**（实测轮辐仍在转，`getComputedStyle(.spokes).transform` 有真实转角）——可以放心给主体组加 filter。
   - 切换主题后**同一 tick 读 `getComputedStyle().opacity` 只会拿到过渡的起始值**（读到 0 不代表没生效），要断言主题态就读 class / `aria-pressed`，或等过渡结束再读。
6. **a11y 陷阱**：`@media (prefers-reduced-motion: reduce) { button { display: none } }` 这类"关动效就藏按钮"的写法，会把**与动效无关的控件**（昼夜切换）一起藏掉。要收窄到具体控件（`#toggle`）。
7. **夜里才成立的元素**：白天不该出现的（如白天场景里的车灯光锥）别硬塞——用主题态控制显隐，既保物理正确又不浪费元素。

相关：[[reference-svg-loop-animation-checks]]、[[feedback-frontend-craft-bar]]。
