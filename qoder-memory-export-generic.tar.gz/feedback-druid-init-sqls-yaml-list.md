---
name: feedback-druid-init-sqls-yaml-list
description: Druid connection-init-sqls 在瀚高 JDBC 驱动下必须用 YAML 列表格式，不能用分号分隔多语句
metadata:
  type: feedback
---

Druid `connection-init-sqls` 配置多条初始化 SQL 时，**必须使用 YAML 列表格式**，不能用分号拼接为单字符串。

**Why:** 瀚高（HighGo）JDBC 驱动不支持在单次 execute() 中执行分号分隔的多条 SQL 语句，会报 `语法错误 在 "xxx" 或附近的`。Druid 的 YAML list 格式会让它逐条执行，每条单独 execute()。

**How to apply:** 配置 application-highgo.yml 时：
```yaml
# 错误（分号拼接）：
connection-init-sqls: SET client_encoding TO 'UTF8'; SET search_path TO your_schema, public
# 正确（YAML 列表）：
connection-init-sqls:
  - SET client_encoding TO 'UTF8'
  - SET search_path TO your_schema, your_other_schema, public
```
此规则适用于所有使用 HighGo JDBC 驱动的 Druid 数据源配置。
