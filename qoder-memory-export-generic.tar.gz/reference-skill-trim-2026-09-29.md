---
name: reference-skill-trim-2026-09-29
description: 2026-09-29 技能降量（90→55，停 35）的执行口径、被停能力的去向与复核命令；含"停技能前先抽能力"的做法与 verify-global-setup 的两处判据修正；流程已固化为技能 skill-trim-with-capability-transfer（带只读提及扫描脚本）
metadata:
  type: reference
---

# 技能降量 2026-09-29（90 → 55）与能力去向

**做了什么**：按用户拍板的「标准档」把 35 个技能移入 `~/.qoder/skills-disabled/`（**移走不删、可回退**），技能目录 90 → 55。清单 / 逐条理由 / 整批回退命令在 `~/.qoder/docs/skill-audit-2026-09-23.md` 第六节；改动前快照在 `~/.qoder/.backups/2026-09-29-skill-trim/`。

**Why**：收益是**上下文与触发准确率**，不是磁盘——每个技能的 `description` 都常驻系统提示（Anthropic 官方：启动时预载每个已装技能的 name + description，模型正是靠它选技能），90 条描述既吃 token 又会让同域技能互相抢触发。被停的都是本机没有对应项目的栈（MongoDB / Redis 集群 / uni-app / Next.js）或同域冗余。

**「停技能前先抽能力」是本轮定下的做法**（用户明确要求：尽量不要缺失能力，关相近的要把能力抽到留存内容里）：

| 域 | 被停 | 能力去向（都在留存内容里） |
|---|---|---|
| 办公文档 | 官方 `docx`、官方 `Excel---XLSX`、市场 `excel-export`、市场 `word-document-organizer` | 新建 `office-docs/scripts/docx-surgery.js`（unpack / pack / **跨 run 文本替换** / validate / changes，纯 Node，自测 11/11）+ `office-docs/CAPABILITIES.md`（能力去向表 + 官方 Python 脚本直接调用法 + 仍缺的能力）；官方脚本仍在 `skills-disabled/docx/scripts/`，补装 `defusedxml` 后实测 `unpack.py` rc=0、`comment.py`/`accept_changes.py`/`validate.py`/`pack.py` 的 `--help` 均 rc=0 |
| Redis | 集群 / Search / 安全 / 可观测 / 语义缓存 5 个 | 集群 hash tag 与 CROSSSLOT、安全基线、`INFO`/`SLOWLOG`/`MEMORY DOCTOR` 排障顺序 并入 `rules/databases.md` |
| Spring | AOP / OpenAPI 文档 等 4 个 | AOP 切点与自调用陷阱、SpringDoc 注解与上线自检 并入 `rules/java-spring.md` |
| Python | 设计模式 / 反模式 / 错误处理 / 类型 / 性能 5 个 | 新建 `rules/python.md`（glob `**/*.py`，按需加载：类型 / 结构 / 错误处理 / 测试 / 性能 / 验证） |
| 小程序 | `wechat-miniprogram-dev` | **不需要迁**：留存的 `miniprogram-development` 正文已覆盖云开发（`wx.cloud`）与 `miniprogram-ci` 预览/上传 |

**How to apply**：再遇到"停一个相近技能"时，先问①它有没有只此一家的能力？②这些能力能否落进留存的技能/规则（最好是真代码或规则条目，不是只写"建议重装"）？③留存的对应物是否真的覆盖（要读正文核，别按名字猜——小程序那条就是读了正文才判定无需迁移）。

**两处判据修正（降量后必红，属机制要跟着改）**：
- `verify-global-setup.js` 里 `sk.length < 76` 是写死的技能数下限 → 降量后必红；改为 `< 40` 下限并注明理由（它的作用是抓"技能目录被清空/半删"，不是钉住某个具体数量）。
- 同脚本要求两侧 `mcpServers` 键集合一致，而 `cua-driver` 当初**只装在国际版**（CN 侧不装）→ 曾登记为 `MCP_INTL_ONLY` 白名单后再比较，**新出现的差异仍判红**。**2026-10-08 用户决定对齐：CN 侧也配上同款 `cua-driver`**，两侧均为 `Context7/cua-driver/dbhub`，例外清单已清空、回到严格相等检查。

**顺手修的真缺陷**：3 处记忆 `[[链接]]` 悬空（都是"名字尾巴被截断"型）：`feedback-verify-deploy-real-data` → `feedback-regression-verification`、`hichat-autoupdate-permission-fix` → `reference-hichat-autoupdate-permission-fix`、`windows-bat-encoding-crlf` → `reference-windows-bat-encoding`。教训：改记忆文件名/写新链接后跑 `node ~/.qoder/scripts/verify-global-setup.js`，它逐条查 `[[链接]]` 可解析。

**复核命令（可失败）**：
```bash
node ~/.qoder/scripts/rules-weekly-audit.js --no-fix     # 适用性项 0 新增告警
node ~/.qoder/scripts/verify-global-setup.js             # 全绿（含规则 13 份 / 链接可解析；技能数当时 55，现 56）
bash ~/.qoder/scripts/sync-global-config.sh --check       # IN-SYNC
bash ~/.qoder/scripts/sync-memory.sh --check              # IN-SYNC
```

**流程已固化为技能**（2026-09-29）：`skill-trim-with-capability-transfer`（用户级技能）——六阶段（引用分档 → 停入口不丢能力 → 同步钉死判据 → 收口验收 → 留痕）+ 已知反例，随带只读脚本 `scripts/skill-mention-scan.cjs`：扫 `AGENTS.md` + `rules/` `commands/` `memory/` `skills/` 里对「已不在 `skills/` 的名字」的提及，每条给 `文件:行` + 上下文 + 状态（在 `skills-disabled/` 可回退 / `--names-file` 补的历史名字），并对「已停用 / 能力去向 / 回退」措辞打**留痕提示**；`--strict` 有「待读」即 exit 2，`--selftest` 11 条断言（含在用技能零命中、词边界、非 md 忽略三项负对照）。本机实跑：658 个 md / 38 个已停名字 → 8 个名字 61 处命中（留痕 35 / 待读 26）。
- **提及扫描要分两栏**：有意留痕（写明"已停用 X、能力去向见 Y"）不该当告警反复改；真悬空（把已停技能当当前可用引用、`[[链接]]` 指向不符）才要修。全量命中里绝大多数是文件扩展名与历史记录，别一见命中就改。
- 词边界要排除 `.` 与 `-`：`报告.docx` / `python-docx` / `docx-surgery.js` 都不算 `docx` 的提及（漏了这条 `docx` 会虚高 23 处）。

**相关**：[[reference-qoder-global-setup]]（技能目录布局与当前清单）。
