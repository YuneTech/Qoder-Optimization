---
name: reference-codex-agent-design-lessons
description: 从 Codex 实现借鉴的 agent 设计要点：上下文压缩有损、外部记忆替代上下文保留、AGENTS.md 是交接文档、规则用真实任务验证
metadata:
  type: reference
---

2026-09-16 联网调研 Codex CLI / 桌面端实现后提炼（已体现在本机 AGENTS.md 与记忆设计中）：

1. **上下文压缩（compaction）是有损的**，是"越用越蠢"的根因——不要把关键状态托付给上下文，要在压缩 / 重启前落盘。
2. **外部记忆（文件 / 记忆条目）是可靠召回的唯一方式**：关键节点写工作注记（做到哪、下一步、阻塞点），需要时检索。
3. **AGENTS.md 是"交接文档"而不是"档案"**：只留隐含的、长期的、可验证的约束；保持精简、渐进披露；长流程进技能、领域细节放子规则；膨胀的规则文件本身就是"不听话"的原因之一。
4. **规则有效性用真实任务验证**，不要用"你会遵守吗"式问答代替实测。
5. 工作流：复杂任务先规划；用测试与 diff 验证；并行调研用子代理。

来源（2026-09-16 查阅）：blog.csdn.net/aidoudoulong/article/details/164371608、36kr.com/p/3964788304944647、javaguide.cn/ai-coding/practices/codex-best-practices.html、segmentfault.com/a/1190000048245827
