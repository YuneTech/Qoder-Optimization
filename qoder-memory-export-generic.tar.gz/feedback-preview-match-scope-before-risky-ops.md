---
name: feedback-preview-match-scope-before-risky-ops
description: 全局纪律（2026-10-08 用户要求）：凡按类型/字段/文件名/路径/进程模式等"匹配"定位的风险操作（改/删/启停/覆盖/迁移），必须先只读预览命中范围（含负对照）再执行；机制 risky-match-guard 直接拦危险形态
metadata:
  type: feedback
---

# 按匹配动手前：先预览命中范围

**规则**：凡以**匹配**方式定位对象的风险操作——按类型、字段、文件名、路径、进程模式、镜像名……做**更新 / 删除 / 启停 / 覆盖 / 迁移**——先做三步，再执行：
1. **只读列出命中清单**（`ls` / `find`（不带 `-delete`）/ `pgrep -af` / `SELECT count(*)`+`SELECT *` / `git status`）；
2. **核对数量与边界**，并挑一条「**本不该命中**」的样例做**负对照**（确认它确实不在清单里）——只数数量的"看起来对"会漏掉范围偏移；
3. 确认无误才执行，并把匹配结果落成**显式清单**（或加精确 WHERE / 主键 / 精确 PID）。

**禁止的写法（范围一错就带走正常内容）**：`rm -rf <通配>`、`find … -delete`、`pkill -f <宽模式>`、`taskkill /IM`、无 WHERE（或 WHERE 恒真）的 `DELETE/UPDATE`、按目录名批量搬迁、`git checkout .`。

**Why**：用户 2026-10-08 原话「凡是匹配类型/字段/文件名/路径等进行风险操作，必须先进行匹配，确认匹配正确情况下再去执行，防止匹配范围过大，影响原本正常的内容」。历史教训同源：某内网服务器上一次 `pkill` 模糊匹配误杀 33 个服务（见 那条"远程停机先预览命中"的记忆）；无 WHERE 的改数据是不可逆的（见 [[feedback-database-safety]]）。

**机制**：`~/.qoder/scripts/risky-match-guard.js`（PreToolUse，两侧 `settings.json` 已接线）——拦上面那几类形态并给出预览改法；判据**宁窄勿宽**（只拦"一次错就连带正常内容"的写法），自测 13/13（6 拦 + 6 放行负对照 + 开关）。拦下时的正确响应是**按提示先预览**，不是换写法绕过；确实要放行就把命令改成显式清单/精确条件。

**How to apply**：落盘在三处——`AGENTS.md` 操作安全红线（第一条）、`rules-reminder.js` 每轮提醒第 5 条、本记忆；同族纪律见 [[feedback-backup-before-modify]]（改前备份）与 [[feedback-database-safety]]（改数据先查证）。
