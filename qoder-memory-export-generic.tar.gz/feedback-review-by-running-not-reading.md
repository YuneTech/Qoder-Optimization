---
name: feedback-review-by-running-not-reading
description: 评审他人前端/动效作品必须先真跑+放大+量测再下结论；给可计算判据而非主观感觉；曾差点把正确的 transform-origin 误判成轴心 bug
metadata:
  type: feedback
---

评审他人的前端/动效作品：**先真跑起来、放大到细节、量测关键量，再给结论**；结论尽量给可计算的判据（速度比、切线斜率、时间周期），不要停在"感觉更精致"。

**Why**：评审一份他人的动效作品时，我读到 `.spokes{transform-origin:0 0}` 配 CSS 旋转，当场判定"轴心会落到 view-box 原点、轮子会飞出画面"——这是 SVG + CSS transform 的经典陷阱，逻辑完全讲得通。实测下来是我错了：注入红色标记弧 + 把转速放慢到 9s，两次截图显示标记始终距轮心 ≈51、角度在变，动画与轴心都没问题。**静态推理在渲染引擎面前经常输**；若当时直接汇报，就是个假 bug。

**How to apply**：

- 下"动画没在跑 / 轴心有 bug"这类结论前，必须拿到像素级或可复现证据；同时警惕几个**会骗人的指标**——`document.getAnimations()` 不枚举 `<use>` 影子树里的动画、`getBBox()` 不含自身与祖先 transform、对称图形（8 辐条 = 45° 对称）根本验不出旋转角度。细节见 [[reference-svg-loop-animation-checks]]。
- 挑毛病优先给**能算的**：`2πr/轮转周期` vs 路面速度、瓦片首尾切线斜率、字体栈跨平台 fallback——比"不够精致"有力得多，也不容易被反驳。
- 评价结构分三段：它强在哪（具体到机制/行号）→ 我差在哪（直接承认）→ 它仍可改进（附依据，并标明是取舍还是缺陷）。

相关：[[feedback-frontend-craft-bar]]、[[feedback-verify-before-diagnose]]、[[feedback-regression-verification]]。
