---
name: coremail-webmail-automation
description: 用 Edge CDP 驱动 Coremail XT 类企业邮箱登录与发信的可行做法、外发限制与踩坑；含 Edge 调试端口启动条件
metadata:
  type: reference
---

# Coremail XT 企业邮箱自动化（通用要点）

**场景**：代用户在企业邮箱发信（带附件）/ 核对已发送。手段 = Edge + CDP（Node 内置 WebSocket 直连 9222，脚本放 %TEMP%）。

## 启动带调试端口的 Edge（前置条件，卡过）
- Edge ≥136 在**默认 user-data-dir** 下忽略 `--remote-debugging-port`；必须配独立 `--user-data-dir`。
- `...\Microsoft\Edge\Application\msedge.exe` 是启动器桩，**不转发**调试参数；要用带版本号的真实 exe（如 `...\Application\153.0.4234.48\msedge.exe`）。
- 独立 profile 无登录态；搬 Cookies 时普通复制被文件锁挡住，用 `esentutl /y` 实测可行。

## 登录
- SSO：企业统一登录入口的 `emailLogin.html`；`input[type=text]`(账号) + `select#email-domin`(域) + `input[type=password]` + `.para-btn-login`。
- 报"用户名或密码错误…还剩 N 次"就是凭据被拒，**别再试密码**，改走短信登录：`input[placeholder=手机号]` / `input[placeholder=验证码]` + "获取验证码"。
- 密码框用 `Input.insertText` 后按钮可能仍处禁用（opacity）态点不动；JS setter + `input`/`change` 事件提交更稳。

## 发信（已验证的完整路径）
1. 附件：`DOM.getDocument{depth:-1,pierce}` → `DOM.querySelector('input[type=file]')` → `DOM.setFileInputFiles`。
2. 收件人**必须走标签编辑器**：合成 mousedown/mouseup/click 打到 `ul.tag-editor` → JS `focus()` 其 `textarea` → `Input.insertText(地址)` → 合成 keydown/keypress/keyup `Enter` 生成标签。
   - 直接 JS 设 `input[name=to].value` 或 `location.hash='#mail.compose|{"to":...}'` 只填隐藏框，提交报"请填写收件人地址"。
   - `.tag-editor-delete` 合成点击删不掉已存在的标签（实测无效）。
3. 主题 `input[name=subject]`；正文 `iframe.ke-edit-iframe` 的 `contentDocument.body.innerHTML`（KindEditor）。
4. 发送按钮、左侧导航只认**真实鼠标事件** `Input.dispatchMouseEvent(mouseMoved/Pressed/Released)`；合成 click 常无效。
5. 直达已发送可用 `location.hash='#mail.list|{"fid":3}'`。
6. 证据：发送成功页面**停在确认页**，hash 仍是 `#mail.compose`，正文变"邮件已发送 + 收件人"；已发送列表可见 收件人/主题/日期，详情里有 `普通附件 (1 个) xxx.zip (约 170K)`。

## 坑
- **企业外发限制**：站外地址（outlook 等）被拒——"邮箱地址无效或发信受限…你只能给本站的用户发送信件"。
- 该错误弹窗按钮是 **忽略并发送 / 移除错误收件人 / 取消**，**没有"确定"**；按猜测文案找按钮会关不掉、弹窗持续叠在页面上。**先 dump 弹窗 innerText 拿到真实按钮文案再点**。
- `location.hash='#mail.compose|{}'` 会**带出上一封草稿的收件人**；开"新信"后必须核对 `input[name=to]` 真实值。
- hash 不变 ≠ 发送失败（确认页 hash 仍是 compose），判定要看页面文案/弹窗。

## 附件与发送按钮（2026-09-23 二次实操补充）
- **附件路径必须带真反斜杠**：用 bash heredoc 写脚本会把 `\\` 吞成 `\`，CDP 收到的路径没有分隔符 ⇒ 附件名被显示成"用户名+目录名连成一串"、上传 **0B / 提示"未知错误"**。修法：脚本一律用 Write 工具落盘（不经 shell 转义），或路径写正斜杠。
- **上传成功的可失败判据**：`.u-fileupload-success` 数量 ≥1 且页面出现"1 个文件共 270.05K"；失败行在 `.u-fileupload-error`，其删除链接是 `a.j-delete`（**合成 mousedown/mouseup/click 就能删**，即使按钮不可见/坐标为 0）。
- **发送按钮 = `span.u-btn-primary`**，innerText 是"发 送"（中间有空格）⇒ 选择器用 `/发\s*送/` 且只认 `.u-btn-primary`，别用"文本 == 发送"精确匹配（会一次都匹配不到）。
- **写信是独立标签页**（`.mltabview-trigger`）。若当前停在「已发送」等列表页，写信页的 DOM 存在但 `offsetParent` 为 null；必须先用真实鼠标点标签（约 `(428,54)`）切回去，按钮才算可见、才点得动。
- 点一次"发送"不必然生效：**必须独立核验「已发送」里新增了那一条**（本次第一次点击后回到首页但没发出去，切回写信标签重发才成功）。成功的判据 = 确认页出现"邮件已发送" **且** 已发送列表条数 +1、附件名与大小正确。

## 登录补充（短信通道）
- 短信登录 tab 用**合成** mousedown/mouseup/click 可切（同一坐标的真实鼠标点击当时没生效）。
- 国家区号 `select#email-domin` **与密码登录共用同一个 id**，默认值是 **+994（阿塞拜疆）**——填手机号前必须显式切到 `+86`，否则验证码发到错误的国家码。
- 登录按钮是 `button.para-btn.para-btn-login`（innerText "登 录"，**不是 input**）；选择器匹配不到时用 `document.elementFromPoint(x,y)` 定位真实元素再按坐标点。验证码输入框 `input[placeholder=验证码]`，`JS setter + input/change` 填值有效。
- 验证码有效期以页面倒计时为准（约 120s 起算），拿到就立刻提交。

**Why**：代发分享包时连卡三处——外部收件人被拒、错误弹窗关不掉、收件人标签录不进；最后靠"真实鼠标事件 + 标签编辑器路径 + 先读按钮文案"走通。
**How to apply**：下次代发企业邮箱或做同类老式 webmail 自动化，按上述顺序执行；动手前先用探针 dump 页面真实 DOM 与文案，不按猜测点击。相关：[[reference-browser-use-viewport]]
