---
name: tooling-windows-window-capture
description: 截第三方应用窗口（微信开发者工具 / Cocos 编辑器这类没有截图 API 的窗口）用全局脚本 capture-window.ps1；必须先 SetProcessDPIAware，否则缩放屏上截出来整体偏移
metadata:
  type: reference
---

需要"把某个桌面窗口截成 PNG 文件"当验收证据时（前台改动要真跑 + 截图），用本机全局脚本：

```
powershell -NoProfile -ExecutionPolicy Bypass -File ~/.qoder/scripts/capture-window.ps1 `
  -Hwnd <窗口句柄> -Out <绝对路径.png>
```

- **Hwnd 从哪来**：computer-use 的 `list_windows` 返回的 `id` 就是 Win32 HWND（十进制），直接传。
- **Why（踩过的坑）**：PowerShell 5.1 默认 **DPI-unaware**，`GetWindowRect` 返回的是**逻辑**坐标，
  而 `CopyFromScreen` 按**物理**像素抓 → 在 150% 缩放屏上截出来整体左移、内容错位（实测 1250×912 vs 真实 1875×1368）。
  脚本已在 Add-Type 后立刻 `SetProcessDPIAware()`，所以**不要绕过脚本自己写 CopyFromScreen**。
- **How to apply**：适用对象是"没有任何截图/预览接口的第三方 GUI"——微信开发者工具（`cli.bat open --project <产物目录>`
  能把模拟器起起来，但 IDE 不落任何截图文件）、Cocos 编辑器面板、其它 Electron 工具。
  浏览器页面截图仍走 browser-use / playwright；Qoder 自己的 MCP 截图只回内联图，不存盘，做不了留档证据。
- 截完把 PNG 存到目标项目的**构建产物目录**（如 `client/build/art-verify/`，通常已被 gitignore），
  在文档/台账里写清路径，避免把二进制证据塞进版本库。

## Word/Office 文档类取证（2026-10-13 实证，docx 交付物验收）

对"用 Word 打开文档截图比对"这类需求：

1. **打开**：`cmd /c start "" "<docx路径>"`（.docx 关联 WINWORD）。
2. **窗口状态修复**：Word 窗口可能处于异常"还原态"（实测 160×39 @(121,121)，`IsIconic`=false、
   `IsWindowVisible`=false，MCP 报的 bounds 也是 160x39）——此时先 `ShowWindow(hwnd, 3)`（SW_MAXIMIZE）
   拉回全屏；`capture-window.ps1` 的 SW_RESTORE 只会还原到这个畸形尺寸，不顶用。
3. **免注入滚动定位（关键）**：不要向 Word 发 Ctrl+End/PageDown（按键会扰动窗口、且实测触发前台翻转）；
   改用 COM 定位后截图：
   ```powershell
   $w=[Runtime.InteropServices.Marshal]::GetActiveObject('Word.Application')
   $doc=$w.Documents | Where {$_.Name -like '*关键字*'}   # 定位已打开的可见实例
   $t=$doc.Tables.Item($doc.Tables.Count)                 # 目标表（可先断言行数）
   $doc.ActiveWindow.ScrollIntoView($t.Rows.Item($k).Range)  # 滚到第 k 行；整页下滚用 LargeScroll(1,0)
   ```
   然后 `computer-use get_window_state`（include_screenshot）截图——全程零按键、零光标。
   COM 只读操作不弄脏文档（选中/滚动/视图都不置 modified）。
4. **PDF 导出链路本机不可用**：Word COM `ExportAsFixedFormat` 出的 PDF 会被**企业加密**（文件头非 %PDF、
   无 startxref，pdfjs 报 Invalid PDF structure）——别浪费时间在 PDF→渲染这条链上，直接走窗口截图。
5. 任务留存脚本样例：`%TEMP%/qoder-work/tms1/{maximize,scroll_into,select_range,bigscroll}.ps1`。

## 同一套手段的边界：能截、能点外壳，但点不动"画布"

实测（微信开发者工具的模拟器）：`computer-use` 的 SendInput 点击**对 IDE 自己的 UI 有效**
（菜单、工具栏"编译"按钮、构建面板都响应，靠它建过 Cocos 构建任务），
但**送进模拟器 canvas 的点击，应用侧完全无反应**（单点、双击都试过，引导"第 1/7 步"一步都不动）。

- **Why:** 这类 GUI 把画面渲染在独立的 canvas/webview 里，注入的鼠标事件不会被翻译成应用内部的触摸事件。
- **How to apply:** 对这类目标，**只能"启动 + 截图 + 读应用自己上报的回执"，不能做交互自动化**。
  需要点验时改走：① 浏览器版产物 + playwright（可注入、可读 console/网络）；② 应用自埋的自检事件落库后回读。
  不要反复重试点击，也不要因此判"功能坏了"——先换手段。

