---
name: feedback-use-existing-tools-first
description: 执行任务前必须先盘点已有规则/技能/MCP，优先调用现成工具，不凭记忆猜测答案
metadata:
  type: feedback
---

执行任务时，**先查找并使用已有的规则、技能、MCP**，确保最佳效果，而不是从零凭记忆猜。

**Why:** 已装了成套技能、规则与 MCP，就是要用的——不去查就直接回答，等于白装。凭记忆写的答案可能过时、遗漏关键细节，不如调用专门技能获取最佳实践。

**How to apply:**

### 匹配优先级（每次任务动手前执行）

1. **已装技能**：按领域搜 `~/.qoder/skills/` 目录，有对应技能就 `Skill` 调用
2. **已配置规则**：检查 `~/.qoder/rules/*.md` 是否覆盖当前领域（自动触发或手动引入）
3. **已连接 MCP**：`mcp_list` 搜关键词，找到就 `mcp_call` 调用
4. **官方文档**：context7 或 WebFetch 查最新 API
5. **自身知识**：最后手段，必须标注"未查文档，可能有误"

### 具体做法

- 接到任务后 30 秒内完成工具盘点（Glob 搜技能目录 + Grep 搜规则关键词 + mcp_list）
- 不确定有没有对应工具时，**先查再答**——30 秒查找远好过产出错误答案再返工
- 缺工具就按 `feedback-auto-install-domain-tooling` 流程自动装
- 已有技能覆盖的模式（Spring Boot CRUD、Vue 组件、Tailwind 设计系统、PG 索引优化等）直接调用，不自己编造

相关：[[feedback-auto-install-domain-tooling]]、[[feedback-auto-add-global-extensions]]、[[reference-qoder-global-setup]]
