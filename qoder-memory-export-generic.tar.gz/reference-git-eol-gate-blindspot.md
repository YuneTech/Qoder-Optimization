---
name: reference-git-eol-gate-blindspot
description: git 的行尾三坑：属性覆盖型门查不到 i/-text 的 CRLF blob、renormalize 对它不动、git grep 零命中会让 set -e 的门"干净地退 1"
metadata:
  type: reference
---

在 `core.autocrlf=true` 的 Windows 仓库里做"全库 LF"策略时，2026-09-23 实测到三条反直觉行为：

1. **属性覆盖型的门有盲区**：`.gitattributes` 写了 `* text=auto eol=lf`，门只问"这份文件被属性覆盖了吗"，
   于是**策略生效之前入库的 CRLF blob 永远绿**。更坑的是 `git ls-files --eol` 会把这种 blob 报成 **`i/-text`**
   （即使它 0 个 NUL、看着就是文本），而按 `i/lf`/`i/mixed` 取样的判据第一句就把它 `next` 掉了。
   ⇒ **这一维要直接读字节**：`git grep --cached -Il "$(printf '\r')" -- '<源码扩展名>'`，命中即红。

2. **`git add --renormalize <路径>` 对它一动不动**（因为 git 认为它是二进制，不套换行过滤器），
   跑完 `git diff --cached` 是空的，看着像"已经修好了"。
   ⇒ 正确修法：把文件整份写成 LF（脚本里 `split('\r\n').join('\n')` 再顺手 `split('\r').join('')` 清残留裸 CR），
   然后 `git add <那一个路径>`；复验用 `git cat-file blob :<路径>` 数 0x0D 字节，别信 `--renormalize` 的沉默。
   改完必须证明**只动了换行符**：把 HEAD 版本去掉 CR 与新版逐字比对。

3. **`git grep` 零命中退 1**，在 `set -euo pipefail` 的门脚本里写成 `n=$(git grep ... | wc -l)`
   会让"仓库干净"变成"**整条脚本不打印任何东西、退出码 1**"——症状像门坏了，实际是门太干净。
   ⇒ 退出码单独接住（`hits=$(...) && rc=0 || rc=$?`），`rc>1` 才叫量具没跑成；
   计数用 `printf '%s\n' "$hits" | grep -c .`，不要复用 `| head` 二次跑 grep（命中多时 SIGPIPE 退 141 会撞同一个坑）。

4. **测量行尾别用 `grep -c $'\r$'`，要用字节数**（2026-10-06 实测）：同一条命令在 `$(...)` 里返回 1753/1753，
   直接在 Bash 工具顶层跑同 pattern 对同一类文件返回 **0**，而 python 数出 **CR 1240 / LF 1240、无 NUL、UTF-8 合法**
   —— 即整个文件确实是 CRLF，grep 那次是**假零命中**（工具的 eval 层把 `$'...'` 里的内容吃掉/改写）。
   ⇒ 关于行尾的断言一律用字节计数（`tr -cd '\r' | wc -c` 对比 `wc -l`）或直接 python；
   否则会像本轮一样先得出"文件被 Edit 工具转成 LF 了"的错误结论，再去"修复"一个不存在的问题。

**适用边界**：任何"用 git 元数据判断文件内容"的门（行尾、可执行位、文本性）都要问一句
"它读的是声明还是字节"；只读声明的门对**历史遗留 blob** 天然失明。
同一句话也适用于**我的量具**：模式经工具层转手后可能静默不匹配 ⇒ 计数为 0 时先证"这个模式在这份文件上必然命中"。
相关：tooling-playwright-probe-patterns、feedback-fix-and-sweep、feedback-pseudo-verification-shapes。
