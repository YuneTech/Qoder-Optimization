---
name: github-actions-quota-block
description: 私有仓库 CI 全红的真因＝GitHub Free 的 2000 Actions 分钟/月被自己烧穿；三种 0 步秒红读数、个人版无 billing API、止血与根治路径
metadata:
  type: reference
---

# GitHub Actions 配额烧穿：识别读数与处置（2026-10-07 实测）

## 现象

`<github-user>` 账户下**所有私有仓库**的 CI 从 2026-10-05 08:29（北京）起全红，
红得"不像代码问题"：本地全绿、推上去秒红、没有任何测试输出。

## 三种读数（任一命中即为配额挡，不是代码缺陷）

| 读数 | 命令 | 配额挡的样子 | 正常失败的样子 |
|---|---|---|---|
| job 存活时长 | `gh api repos/<o>/<r>/actions/runs/<id>/jobs` | `started→completed` **2 秒**、`steps=0` | 数分钟、`steps` 有值且某步 failure |
| run 根本没有 job | 同上端点 | `total_count=0` / run 对象里 `jobs: null` | 有 job |
| 日志不存在 | `gh api .../actions/jobs/<jid>/logs` | Azure Blob 返回 **`BlobNotFound`**（runner 从未起过） | 有日志 |

**决定性证据**是 annotation（端点易写错，见下）：

```
gh api repos/<o>/<r>/check-runs/<job_id>/annotations \
  --jq '.[] | "[\(.annotation_level)] \(.title) :: \(.message)"'
→ "The job was not started because recent account payments have failed
   or your spending limit needs to be increased."
```

- ⚠️ 端点是 **`/repos/{o}/{r}/check-runs/{check_run_id}/annotations`**（Actions job 的 `check_run_id` 等于 `job.id`）。
  写成 `/actions/jobs/{id}/check-run/annotations` 会 **404**，会误判成"没有注解＝不是配额"。
- ⚠️ commit 级 `.../commits/{sha}/check-runs` 在 `total_count=0` 的 run 上是**空数组**，别拿它当"没有拦截证据"。
- ⚠️ **run 对象的 `run_id` 恒为 `null`**（2026-10-07 在 list 与单 run 两个端点各测一次都是 null）⇒ ID 一律取 `.id`；
  拿 `.run_id` 会得到空变量、下一跳 404，被误读成"run 不存在"。`status=failure|success` 查询参数本身是好的，别把空返回算到它头上。
- ⚠️ **gh 内置 gojq 不接受中文对象键**：`{存活秒:...}` 直接 `failed to parse jq expression ... unexpected token "存"`（前置报错、什么都不输出，容易被当成"这个 run 没数据"）⇒ jq 构造对象只用 ASCII 键。
- 判据能失败的对照组读数：成功 run `37567787501` 的 `static-gates` 是 `secs=217 / steps=8`，
  `check-runs/<id>/annotations` 里闸门文案命中数 `=0` ⇒ 阶梯在对照组上必须判"非配额"，否则是判据写错（先查上面三条）。

## 根因（机制）

GitHub 收费的不是代码托管，而是 **Actions 托管 runner 的算力**：

- **GitHub Free：2000 分钟/月 + 500 MB 工件存储 + 每仓库 10 GB 缓存**；**公共仓库用标准 runner 不计配额**（免费）。
- 私有仓库每次 CI 都在 GitHub 的虚拟机上跑，按 runner 单价扣配额。
- 本机实测折算：`ironoath` 的 `build-and-gates` 用 **ubuntu-latest**，抽样 8 次成功 run
  平均 **5.4 分钟/次**；9-17 起 500 次 run 中 **391 次成功** ⇒ **≈2111 分钟 > 2000**，正好在 10-05 前后烧穿。
- 高频小步提交（每格一推）＋ 每 run 5 分钟 ⇒ 一天 25 次就 ~140 分钟，**两周见底**。
- `llm-gateway` 用 **windows-latest**，单价高于 Linux（文档现价 Windows 2 核 $0.010/分钟、macOS $0.062，
  Linux 为最低档），**若解冻会比 ironoath 快一倍以上烧配额**（倍率的统一口径未核实，只报文档单价）。

## 个人版查不到用量（重要盲区）

`users/<u>/settings/billing`、`accounts/<u>/billing`、`users/<u>/settings/billing/usage` **三个端点全 404**
——billing/usage API 只对**组织 / 企业**开放。**个人版只能去网页 Settings → Billing and plans 看**。
⇒ 不许凭 API 拿不到就断言"没超额"，也不许把"配额还剩多少"写成已验证结论。

文案 "recent account payments have failed **or** your spending limit needs to be increased" 是**二合一**：
挂了卡且扣款失败 / 花费上限为 $0 需上调，两种都会出这句话。**账户是否绑了付款方式无法程序化确认 ⇒ 未验证**，
要定性必须看网页。两种情形的止血动作相同，所以不必先定性再动手。

## 自托管车道实测结论（2026-10-07 已跑通，attempt=2 全绿）

**计费闸门不挡自托管 runner** —— 配额见底期间 job 照样被派发并真跑完（`gates-selfhosted` 在本机
`ironoath-win-self` 上 completed/success，8 步真执行）。⇒ "解冻前拿不到任何 CI 读数"是错的，
静态门类门可以立刻恢复；只有要 `services:`（Mongo 等）的服务端全量测试恢复不了。

### 硬坑：runner 目录路径**不能带空格**

装在 `D:\Program Files\actions-runner\` 时，"Static gates" 步秒红，日志只有一行：

```
shell: D:\software\Git\usr\bin\bash.EXE --noprofile --norc -e -o pipefail {0}
/usr/bin/bash: D:\Program: No such file or directory
##[error]Process completed with exit code 1.
```

**根因**：Actions 把临时脚本路径**不加引号**拼进 bash 命令行，而临时脚本落在 runner 工作目录下
⇒ 路径含空格就在第一个空格处被切断，`D:\Program` 被当成脚本文件名。
`--work` 只能给相对路径（仍在 runner 根下），**绕不开** ⇒ 唯一解是把 runner 本体挪到无空格路径。

- 本机现装 **`D:\actions-runner\ironoath\`**（label `ironoath-self`，name `ironoath-win-self`）。
- ⚠ 这与"软件一律不装 C 盘 ⇒ 举例 `D:\Program Files\...`"的默认落点**直接冲突**：
  **actions-runner 属例外，必须选无空格目录**（`D:\actions-runner\` 这类）。同类"路径含空格即坏"的
  工具（Node 生态里不少 spawn 实现）装前先想这一条。
- 换路径后旧注册要注销：`gh api -X DELETE repos/<o>/<r>/actions/runners/<id>`，再在新目录
  `config.cmd --replace`（registration token 1 小时过期，每次重取）。

### 本机跑 `scripts/check.sh` 要 node 20

默认 node 24 会让末段 `test-client` 判红（`node --test` 的目录形态在 24 上跑不起来，仓库文档已注明）
⇒ 车道里显式 `actions/setup-node@v4` 装 20，**不要**复用 `D:\Java\nodejs\node20.13.0`
（那会让 workflow 依赖"这台机器恰好装在那儿"，换机即静默漂移）。

### runner 持久化（已做，免管理员）

`cmd //c run.cmd` 随会话结束即停；机器重启后不自启 ⇒ job 排队到超时（**那是"没验"，不能读成通过**）。

- 自启壳：**`D:\actions-runner\ironoath\run-hidden.vbs`**（wscript 起 run.cmd，窗口 style 0）
  + Startup 快捷方式 `~\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\GitHub-Actions-Runner-ironoath.lnk`（960 B）。
- 为什么不用计划任务：`Register-ScheduledTask -AtLogOn` 在本机 **PermissionDenied 0x80070005**（要管理员），
  而 Startup 文件夹免提权；为什么套 vbs：WT 当默认终端时会无视 `/WindowStyle Hidden`，开机弹常驻终端窗口
  （见 `reference-autostart-console-popups`）。
- 重建脚本：`D:\actions-runner\ironoath\register-autostart.ps1`。**回退**＝删那个 .lnk。
- ⚠ 硬杀 `run.cmd` 后，服务端旧 session 还会占约 1~2 分钟，新 listener 会打
  `A session for this runner already exists` 并每 30 秒重试 —— 等它过期即恢复，**不是注册坏了**，
  别急着重装 runner。

## 止血手段的真实价值（先量化再动手，别照抄"通用最佳实践"）

按 460 次成功 run / 15.7 天样本实测（2026-10-07 用 `/audit-ci-cost-levers` 在 `D:\Java\GitHub\ironoath` 复跑：
196 次/3.1 天窗口 ⇒ 命中 41.5%、净回收 **22.8%**、D 自测 5.7 分钟——**绝对值随取样窗口漂移，"单项不够"的结论不变**）：

| 手段 | 读数 | 判定 |
|---|---|---|
| 日均消耗 | 29.3 次 run × 5.4 分钟 = **158 分钟/天** vs 上限 66.7 | 超支 **2.4 倍**，12-13 天必烧穿 |
| `concurrency: cancel-in-progress` | 36% 的推送间隔 < 单次耗时 | 只回收"取消后不再跑的那半截"（**已消耗分钟照常计费**）⇒ 约 **22%**，不够达标 |
| `paths-ignore: docs/**` | 最近 120 笔里纯 docs 提交 = **0 笔**；且窗口内 `docs/` 一次都没被改动（反证：`git merge-base --is-ancestor 15297737 HEAD~120` 成立，最后改 docs/ 是 2026-10-02） | 命中率 **0**（真读数、非坏谓词），不做 |
| `paths-ignore: '**.md'` | 读 md 的门脚本 **20 个，其中 19 个在 CI 调用链上**（workflow 直连 3 + 经 `check.sh` 传递 16）。**2026-10-07 用技能 `/audit-ci-cost-levers` 复扫，把本条旧记的"3 道真门"纠正为 19 道** | **会连带跳过一大片门禁**（`check-checklist-*` 收口清单.md、`check-doc-counts` AGENTS.md、`check-eol-policy` 扫 `*.md` 行尾、`check-client-orphans`/`check-core-wiring` 验收矩阵.md…）⇒ 禁用。**只查 workflow 有没有点名会把 `check.sh` 背后的门误判成"不在 CI 上"＝危险方向的假绿，必须走传递闭包** |

⇒ **结论：止血单独不够，必须配自托管车道**；两者叠加后日均托管消耗降到约 123 分钟，
仍需把推送频率压到 ~12 次/天才不复发（另一会话已把"小改动只提交、阶段收口统一推"写进交付规则）。

## 处置（按代价从低到高）

1. **止血（已做 2026-10-07）**：`concurrency` 取消旧 run（ironoath 此前没有）；`paths-ignore` 经量化后**不做**。
2. **根治（已做 2026-10-07）**：自托管 runner + `.github/workflows/ci-selfhosted.yml` 跑 46 道静态门，
   **不消耗托管分钟**；服务端全量测试仍待托管车道解冻（`services:` 自托管不支持）。
3. **掏钱**：绑卡 + 上调花费上限（约 $4 / 4000 分钟增量）。**属对外可见 + 花费，必须用户本人操作**。
4. **改公开仓库**：公共 runner 分钟免费，但代码是私有的 ⇒ 不适用。

## 适用边界

只解释"**0 步秒红 / 无 job / 无日志**"这一族；同账户下若 job 有 steps 且某步 failure，仍是真实代码问题，
按常规读日志处理。**别把这套读数当万能**：`action_required`（首贡献者待批）、runner 离线、
`workflow_dispatch` 缺 trigger 也会红，但 annotation 文案不同。

## 读数口径（自托管车道落地后，2026-10-07 起）

- **推后以 `gates-selfhosted` 的结论为准**（`gh run list` / `gh run view --json`）；托管 `build-and-gates` 同 commit 的 **0 步秒红属预期**，不要再当缺陷信号逐条排查。
- **同分支连推会 cancel 掉前一次的 in-flight run**（`ci-selfhosted.yml` 的 `concurrency: cancel-in-progress`）——**`cancelled` 不是红**；连环推时只能读到"最后一次"的结论。
- 首个带批量的真读数：推送后 `static-gates = success`（11m26s，跑满静态门）——"解冻前拿不到任何 CI 读数"的旧结论正式作废。

相关：`github-access-setup`、tooling-background-task-exit-code
技能分工（2026-10-07 建）：**`diagnose-github-actions-quota`** 管定性阶梯 + 端点陷阱 + 对照组 + 折算脚本（`scripts/quota-usage.cjs`，实测 mean 5.3 分/次 × 466 次 = 2452 分钟 > 2000）；**`audit-ci-cost-levers`**（另一会话建）管止血收益测算与车道选型。本条只留本机读数与坑，命令形态以技能为准。

## 另一侧（非 CN）2026-10-07 的独有读数（无损并入，未删除本侧正文）
按 460 次成功 run / 15.7 天样本实测：
| `paths-ignore: docs/**` | 最近 120 笔里纯 docs 提交 = **0 笔** | 命中率 **0**，不做 |
| `paths-ignore: '**.md'` | 3 道真门读 md | **会连带跳过门禁**（`check-checklist-*` 读收口清单.md、`check-doc-counts` 读 AGENTS.md、`check-eol-policy` 扫 `*.md` 行尾）⇒ 禁用 |
