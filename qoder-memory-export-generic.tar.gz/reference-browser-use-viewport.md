---
name: reference-browser-use-viewport
description: browser-use 内嵌浏览器验收实测：视口 hidden 的**首要根因=Qoder 侧边栏未打开或会话不在主窗口**（2026-10-16 用户口径）；修法=操作电脑把主窗口调前台+打开侧边栏；另有 navigate→screenshot 恢复法、headless Edge/playwright 替代、动画时钟冻结等
metadata:
  type: reference
---

本机（Windows）用 browser-use MCP 做前端验收时的实测事实汇总（ + 2026-10-16 补）：

- **【2026-10-16 用户口径 · 首要排查项】视口 0×0/visible=false 的根因大多不是环境玄学，而是：① Qoder 侧边栏（内置浏览器所在面板）没打开；② 当前会话不在主窗口。** 修法：**操作电脑**（computer-use/cua）把任务窗口调到主窗口并**打开侧边栏**，再截图即恢复；不要再先重试 N 次截图浪费时间。以后遇到 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE` 一律先查这两点。


- **视口问题是间歇性的，不是永久的**：某轮 `take_screenshot` 报 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE`（viewport=0x0、visibilityState=hidden），**后续会话重试即恢复**（实测截图成功，视口 ~832×849；另一会话为 724×729，尺寸随会话变化勿硬编码）。截图失败先重试导航+截图，不要直接放弃视觉验证退回 DOM 断言。
- **同会话内视口 hidden 的修复手段（2026-09-18 实测）**：重试 navigate/reload/select_page 无效时，用 computer-use 插件 `list_windows` 找到 Qoder 主窗口 → `activate_window`（window 传完整对象 `{app, id, title}`，id 必须字符串）把宿主窗口调到前台，之后 `take_screenshot` 立即恢复，无需重开会话。（同日另一场景：尚未试到这招，computer-use 就整体被 browser_url_policy 停用，见下。）
- **失败态特征串**：报错文案为 `NATIVE_BROWSER_VIEWPORT_UNAVAILABLE ... (viewport=531x617, visible=false, attached=false, cdpAttached=true, visibilityState=hidden)`；本轮连续重试 3 次均失败，**再 navigate 一次同一 URL 后立即恢复**——"navigate → screenshot" 组合比单纯重试截图有效。
- **take_screenshot 参数白名单**：仅接受 format/quality/uid/fullPage/filePath，传 name 等额外键直接报 `params must NOT have additional properties`；要存档用 filePath。
- **局部放大看细节**：内嵌浏览器视口只有 ~531×617，全场景截图看不清细节。注入式改布局即可放大：`document.body.style.display='block'` + 给容器设内联宽度（如 `.stage{width:900px}`），再 `window.scrollTo(x,y)` 平移截取局部；注意 scrollTo 会被 `document.body.scrollWidth` 截断，别按想象的坐标算，需用页面里可辨识的固定元素（如太阳圆心+半径）反推当前缩放与可视区域。
- **SMIL 动画存活的可失败判据**：不用截图也能证明真在跑——隔 0.6s 读两次动画元素父级的 `getCTM()` 求 `Math.atan2(m.b,m.a)`（旋转角）与 `getComputedStyle(line).strokeDashoffset`（虚线偏移），两者都变化即证动画运行；比值单张静态截图更硬。
- **Element Plus 弹窗超高时的滚动**：对话框高于视口时，滚动容器是包装层 `.el-overlay-dialog`（`dialog.closest('.el-overlay-dialog')` 直接设 scrollTop），**不是** `.el-dialog__body`（overflow: visible）、不是 window（scrollY 恒 0）；且 `.el-overlay` 的 scrollHeight 可能虚报等于 clientHeight，别用它判断可滚。
- **弹窗消歧**：多弹窗并存（如"新增检测规则"+"浏览模板"）时，用 `d.querySelector('.el-dialog__title')?.textContent` 匹配目标弹窗；用 `textContent.includes(...)` 匹配会命中错误弹窗（表单弹窗文本里含"浏览模板"按钮文案）。
- **el-select 下拉**：所有 popper 的 options 都在 DOM 里（含隐藏的），先按 `offsetParent !== null && computed display !== 'none'` 过滤出可见 popper 再点选。
- **交互会改变弹窗状态**：点卡片"应用"后模板弹窗自动关闭——跨多次 evaluate_script 调用时每次重新查弹窗存在性，别缓存元素引用。
- **evaluate_script 用法**：参数名是 `function`（传 JS 函数声明字符串），支持 async；单次 MCP 调用 ~15s 超时，长流程拆成多次调用。textarea 与 input 的原生 setter 不同；`Illegal invocation` 多为 prototype setter 用错或对 NodeList 直接调方法。
- **本地静态 HTML 可直接预览验收（2026-09-18 实测）**：`navigate_page` 传 `file:///C:/...` URL 即可打开本地 HTML，无需 dev server；改文件后用 `{"type":"reload","ignoreCache":true}` 刷新生效。
- **CSS 动画的截图验收技巧**：单张静态截图验证不了动画是否在跑；间隔截两张图对比相位差异（如云朵位移、车轮辐条角度、烟团出现/消失）即可作为"动画真实运行"的可失败判据。SVG 内嵌动画元素（transform-box: fill-box + CSS keyframes）在此浏览器下工作正常。
- **视口 hidden ≠ 动画代码坏了（2026-09-18）**：内嵌浏览器面板未打开时页面隐藏，`document.timeline.currentTime` 恒为 0 不推进，所有 animation `playState` 仍 'running'，但 computed transform/dashoffset 两次采样不变——这是时钟冻结的环境态，不是动画没写对。判据：采样 `document.timeline.currentTime` 是否推进 + `visibilityState`，先判环境再怀疑代码。
- **computer-use 截浏览器窗口会被 URL 政策拦停（2026-09-18）**：对 msedge 窗口 `get_window_state` 报 `browser_url_policy / url_verification_required / insufficient_url_confidence`，消息明说 "Computer Use has been stopped for this turn" 并要求收尾时说明原因——Windows 下它无法高置信度确认浏览器 URL；此路不通别重试，整个 computer-use 本回合已停。
- **headless Edge 双帧截图验动画（2026-09-18 实测有效）**：拿不到内嵌视口时的视觉验收替代：`msedge.exe --headless=new --disable-gpu --no-first-run --no-default-browser-check --hide-scrollbars --user-data-dir=<临时目录> --screenshot=<绝对路径.png> --window-size=960,640 --virtual-time-budget=<ms> "file:///..."`，跑两个 budget（如 1200/1450ms）后 Read 两图对比相位（轮辐角、虚线相位、烟团位置）即证动画推进；**必须带独立 --user-data-dir**，否则并入已开的 Edge 会话（传 file URL + `--new-window` 也只提示"已在打开的会话中打开"）；验证完删除临时目录。
- **诚实降级**：实在拿不到视口时用 evaluate_script 程序化驱动页面并读 DOM 完成验收，并明确说"以 DOM 断言代替视觉检查"，不要谎报看到了界面。
- **SPA fallback 干扰**：`curl` 判断本地服务存活时，SPA 会把任意路径答成 `200 text/html`，必须用"不存在路径"对照组 + content-type / 特征串区分。
- **headless Edge 也能截 dev server（2026-09-30 实测）**：不必局限 `file:///`——`--screenshot` 直接打 `http://localhost:8081/...` 同样出真图（`--virtual-time-budget=6000~9000` 给 SPA 足够渲染时间）。内嵌视口彻底拿不到时这是可行的视觉验收路径。**局限**：无法预置 `sessionStorage`/`localStorage`（sessionStorage 不跨进程、cookie 无法从外部注入），所以**只能截"未登录"分支**；"已登录"分支仍需内嵌浏览器 + `evaluate_script` 断言。
- **用"两张 PNG 逐字节相同"做归因对照（2026-09-30 实测有效）**：页面上出现红/崩时，把改动文件临时换回备份版、重截同一 URL，`cmp` 两张图——**相同即证明该红与本次改动无关**。比读代码推理硬。注意：① 换回后要 `sleep` 等 dev server 热编译再截；② 用**独立的 `--user-data-dir`**（如 `edgeprof2`）避免缓存串扰；③ 验完立刻还原并 `cmp` 确认还原成功 + 关键改动标记仍在。
- **内嵌浏览器 sessionStorage 疑似跨 localhost 端口共享（2026-09-30）**：在 `:8081` 里 `sessionStorage.setItem('token', X)` 后，导航到 `:8082` 竟读到同一个 `X`。→ 多应用同机验收时**每次都要 `sessionStorage.clear()` 并回显确认**，且种子值用唯一串，否则判据被污染（实测踩到：一次"负向"结果里 token 仍在，但页面又被弹走，两个事实互相矛盾即为此因）。
- **pointer 动作（click）在无捕获面时也会被拦 → 改 evaluate_script 驱动（2026-10-12 实测）**：`NATIVE_BROWSER_VIEWPORT_UNAVAILABLE` 不只拦 `take_screenshot`，`click` 同样报错；此时用脚本选：antd `<Select>` 先对 `document.querySelector('.ant-select-selector')` 派发 `mousedown/mouseup/click` 打开下拉，再 `[...document.querySelectorAll('.ant-select-item-option')].find(o=>o.getAttribute('title')==='目标')` 派发点击。另：该回合 `mcp__browser-use__*` 曾短暂报 "Tool not found"，`mcp_list({keyword})` 后又可用——重试即恢复。
- **playwright-core + msedge 探针可预置 storage 并出真图（2026-10-12 实测）**：项目 `acceptance/` 自带 `playwright-core`；`chromium.launch({channel:'msedge',headless:true})` + `ctx.addInitScript(()=>sessionStorage.setItem('token',...))` 能截"已登录/需 token"分支（补 headless `--screenshot` 无法预置 storage 的短板），还可用 `page.on('request')` 数请求、`page.click('.ant-select-selector')` 真点。判断"是否真的整页刷新"用 `page.evaluate(()=>performance.getEntriesByType('navigation')[0].type)`。
- **`performance.getEntriesByType('resource')` 是"点击到底有没有发出请求"的干净判据**：比 `list_network_requests` 轻（可数差值、可按 URL 过滤），适合验证"菜单项点了有没有触发 effect"。配合 `it.offsetParent !== null` 过滤可见节点——反复 hover 后 DOM 里会残留**隐藏的旧弹层**，`querySelectorAll` 取到失效节点会导致"点了没反应"的假故障。

相关：[[feedback-verify-fix-in-ui]]。
