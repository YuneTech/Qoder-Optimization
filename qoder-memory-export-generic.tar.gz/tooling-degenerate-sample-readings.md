---
name: tooling-degenerate-sample-readings
description: 两类会产出"看着合理的假读数"的取样现场问题：拿 Actions runner 的浅克隆 _work 检出做 git log 窗口统计（本机实测只有 1 笔历史），以及并行会话在两次取数之间落盘导致的"悬空引用/不存在"快照错觉
metadata:
  type: reference
---

# 退化样本与快照错觉（2026-10-07 实测）

## 一、浅克隆做窗口统计 ⇒ 命中率看着合理但根本不成立

**现象**：在 `D:\actions-runner\ironoath\_work\ironoath\ironoath` 里跑 `paths-ignore --since 120`，
输出 `动了该路径的提交=1`、`命中率=100%`——不变量（只动数 == 动了数）成立，所以脚本自检没报错，但样本只有 1。

**根因**：Actions 给 runner 的检出是**浅克隆**：`git -C <_work 检出> rev-list --count HEAD` = **1**，且存在 `.git/shallow`。
任何 `git log -N` 型窗口统计（提交占比、间隔分布、最后改动时间）在这里都退化成 1 笔样本。

**正确做法**：历史类取数**必须用完整工作克隆**——本机是 `/d/Java/GitHub/ironoath`（1134 笔）。
动手前先跑一条取样现场自检：

```bash
git -C "<repo>" rev-list --count HEAD        # 样本数 < 窗口笔数 ⇒ 这批读数全部作废
[ -f "<repo>/.git/shallow" ] && echo 浅克隆
```

换完整克隆后同一批判据立刻对齐文档记录：`docs/**` 命中 `0/120`；对照 `--glob '**'` 得 `120 = 120`、100%；
`gates-read '\.md$'` = 19 道真门；负例 `'\.zzz$'` = 0。

**适用边界**：runner 的 `_work` 检出**可以**用来跑构建与本机门禁（它要的就是当前提交），
只是不能用来回答"历史上有多少笔提交动过 X"。

## 二、并行会话落盘造成的"不存在"错觉

**现象**：我报某技能"引用了盘上并不存在的 `scripts/ci-cost-measure.cjs`"。实际时间线——
12:15 我 `ls -R` 只见 `SKILL.md` ⇒ 12:19:02 对方落下脚本 ⇒ 12:20:12 对方补上 `## Resources` 条目。
**结论是快照期的真实状态，但被我说成了永久缺陷。**

**判据升级**：存在性 / 悬空 / "没人用"这类**否定式**结论，在并行会话环境下必须：

1. 取数带 `mtime`（`ls -la --time-style=+%H:%M:%S` 或 `stat -c '%y'`），并**隔一轮复测一次**；
2. 报出去之前重跑同一条 `ls`——一分钟内可能已被补齐；
3. 要断"引用无效"就跑到调用链终点：把脚本**真跑一遍**（子命令 + 它自带的对照组 + 负例），
   而不是只看目录里有没有文件。这条与 feedback-verify-before-diagnose 同族，新增的是"时间维度"。

## 三、复验别人写的技能/文档里的数字

不要只看聚合数：跑它**自己声明的对照**（本例是 `--glob '**'` 要 `只动==动了`、`--pattern '\.zzz$'` 要 0），
再核取样现场（第一条）。两条都过才能引用它的读数——否则"绿"可能来自退化样本。

相关：github-actions-quota-block、feedback-verify-before-diagnose、reference-skill-trim-2026-09-29、tooling-background-task-exit-code
