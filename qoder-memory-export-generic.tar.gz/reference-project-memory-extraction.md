---
name: reference-project-memory-extraction
description: 项目记忆（国际版+CN，74 条）提炼为全局资产的成果与口径：四条规则增量、两个全局 agent、一个 dbhub 连接器；含"哪些该提、哪些必须留在项目内"的判据
metadata:
  type: reference
---

# 项目记忆 → 全局资产：提炼口径与成果（2026-09-30）

**做了什么**：把 74 条项目级记忆（`~/.qoder/projects/<slug>/memory/` 国际版 10 个 slug + `~/.qoder-cn/projects/` 3 个 slug）过一遍，**只提可跨项目复用的**，落成全局规则 / agent / 连接器；项目专属的（部署路径、凭据、单个 bug 的修复记录）**留在项目里不动**。

## 提炼判据（下次照这个来）

**提**：跨项目会再遇到的**机理型**教训——框架/库的隐蔽行为、跨系统约定（时区/编码/文案）、验收口径、交互偏好。
**不提**：① 只对某台服务器/某个库成立的地址与凭据（留在项目记忆，凭据另见本机凭据文件）；② 某一个 bug 的修复过程（项目记忆里已有）；③ 未复现的猜测。

## 成果一：四条规则增量（都是"踩过的坑 + 可执行判据"）

| 落到哪 | 提炼自 | 要点 |
|---|---|---|
| `rules/java-spring.md`（新增「运行期排障」节） | 网关/配置管理/多环境部署类项目 | ① 多 profile 服务**必须显式指定 profile**（默认会连到另一个环境的库；症状是查不到数据/终端不在线）；② 跨 fastjson 版本取嵌套对象一律 `getJSONObject(key)`，`get(key) instanceof JSONObject` 恒 false 且只影响快路径（极隐蔽）；③ ACK 超时/命令丢失用**线程名**定位（`nioEventLoopGroup-*` vs `agent-business-*`），修复靠超时预算不是重启；④ 接收 path 的接口必须走统一的编码兼容解码（`%2F` 字面量会伪装成"文件不存在"）；⑤ 列表/查看/恢复/删除要同一口径（多通道写入要 OR 全通道；MyBatis-Plus 里 OR 与 AND 混用要显式加括号） |
| `rules/frontend.md`（新增「请求层与多语言」节） | 管理台类前端 / 监控面板 / 拓扑页 | ① 取消≠失败（去重 abort 要用 `isCancel` 识别，加序号守卫；别改全局去重语义）；② "请求次数"断言先数清实现（`1 + 1 + maxRetries`，业务错误码不触发重试）；③ i18n 三条（长语言用专用短键、服务端渲染文案存参数+双端同键、列头用 min-width）；④ 语义判据取数据字段不从坐标反推（多布局下 X 语义相反）；⑤ 二级信息优先弹窗 |
| `rules/infra-ops.md` | 多环境部署 / nginx 验收 | ① nginx 按 Host 选 server 块（本机 `curl 127.0.0.1` 的 403 不是服务故障；`reload` 不换 master，看 worker 启动时间）；② 时间戳三层对齐（代码层 Timestamp→LocalDateTime 纯字符串 + JVM `-Duser.timezone` + JDBC `SET TimeZone`） |
| `rules/databases.md` | 多 schema 的企业库 / 大表迁移 | ① 跨 schema 必须写限定名，不依赖 `search_path`；② 大表迁移分批且可续跑 |

## 成果二：两个全局 agent（`~/.qoder/agents/`，用户级机制经官方文档核实）

- `runtime-truth-verifier` —— 运行期真值核验：先取现场证据再谈代码；禁止静态反推配置/库结构/拓扑；结论给"结论 + 证据 + 未验证项"三栏。
- `deploy-verifier` —— 部署后真实验收：确认验的是本轮产物；真实浏览器走完整路径含负向用例；计数断言先数清；截图前先清遮挡；服务器自检别用 127.0.0.1。
- 写入位置与格式：`~/.qoder/agents/<name>.md`，frontmatter 支持 `name / description / tools / model / skills / mcpServers`（[官方文档](https://docs.qoder.com/zh/extensions/subagent)）。**注意**：agent 的 description 也参与自动路由（和技能同样的"描述常驻"成本），所以只建真正会重复用的，别铺量。

## 成果三：一个连接器

- dbhub 新增只读源 **`supersql`**——项目记忆里出现过、而原 dbhub 三个源（本地瀚高实例 / 瀚高上的业务库 / PG 上的业务库）覆盖不到的那个库。加之前用 dbhub 自带 `pg` 驱动做了连通性实测 + **负对照**（不存在的库必须报错），确认可达才写进 `dbhub.toml`（DSN 与库名见该文件，不在记忆里重复）。
- **生效时机**：MCP 配置在客户端启动时读，改完要重开会话/客户端才出现 `execute_sql_supersql`（本轮未复测，属"未验证"）。
- 其他项目用到的库同在那两台服务器上，走已有源的 schema 限定名即可，**没有为每个库都开新源**——连接器宁少勿多，够用就行。

## 边界

- 项目记忆**保持原样**（它们是项目内的真源，另有 `sync-projects-junction.ps1` 做同源），本轮的"提炼"是**加全局资产**，不是搬走或改写项目记忆。
- 提炼出的规则条目都写了"为什么"（症状 + 根因），因为下一个项目里症状会换皮出现。
