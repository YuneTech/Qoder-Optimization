---
name: reference-powershell-script-encoding
description: Windows PowerShell 5.1 跑 .ps1 的七个必踩坑：无 BOM UTF-8 中文吞引号、param() 不是首条语句、"$var:" 被当驱动器限定变量、数组里逗号优先于 +（拼参数静默拆坏）、Stop 模式下原生命令 stderr 抛异常、空数组进管道导致旧产物残留、Bash 调用时 $env: 前缀被吞
metadata:
  type: reference
---

用 `powershell -File xxx.ps1` 执行脚本时，下列写法会直接解析失败、绑定错乱或**静默把参数拆坏**（每条都有实测报错）：

1. **中文注释 / 中文字符串 + 无 BOM UTF-8**：Windows PowerShell 5.1 按 ANSI 码页读取无 BOM 的 `.ps1`，多字节序列会吞掉相邻引号，报 `字符串缺少终止符` / `表达式或语句中包含意外的标记`，且报错位置指向**别的行**，极易误判。
   → 脚本本体一律 **ASCII-only**（注释与输出都用英文），需要中文时改存为 UTF-8 **带 BOM**，或改用 `pwsh`。
2. **`param()` 之前存在任何语句**（哪怕只是 `$ErrorActionPreference = 'Stop'`）：调用时带开关参数会抛 `无法将 System.Object[] 转换为 System.Int32` 的 MetadataError，指向 param 行。
   → `param()` 必须是文件的**第一条语句**（前面只允许注释），赋值紧随其后。
3. **双引号内 `"$slug:xxx"`**：`$` 后紧跟标识符再跟冒号被解析为驱动器限定变量（`$slug:xxx`），报 `无效 ':' 后的变量名称`。
   → 写成 `"${slug}: xxx"` 或改用 `-` / `=` 分隔。
4. **数组字面量里逗号优先于 `+`**：`@($src, $dst, '/LOG+:' + $log, '/E')` 会**静默**拆成 `'/LOG+:'` 与 `$log` 两个元素（不报错、不提示），外部程序收到空值参数。实测 robocopy 因此报 `无效参数 #11:「/LOG+:」` 并 exit 16，三轮拷贝全部失败而脚本上层只看 exit code 不易发现。
   → 拼接一律加括号：`('/LOG+:' + $log)`。排查办法是把数组逐元素打印出来看：`$i=0; foreach($e in $a){ Write-Output "[$i] <$e>"; $i++ }`。
5. **`$ErrorActionPreference='Stop'` + 原生命令写 stderr**：`& cmd.exe /c 'rd /s /q 不存在的路径'` 这类调用一旦有 stderr 输出，PS 5.1 抛 `NativeCommandError` **中断整个脚本**（哪怕 `2>$null` 也拦不住，实测有效）。在"改名/建链"这类不可中途停的流水线里尤其致命。
   → 封装一个 `Invoke-Cmd`：进入时把 `$ErrorActionPreference` 临时设为 `Continue`，`try/finally` 还原，并合并 `2>&1` 返回 `{Exit,Out}`；所有外部命令走它。
6. **空数组进管道 = 下游 cmdlet 一次都不执行**：`$list | ConvertTo-Json | Set-Content $path` 在 `$list` 为空时**不写任何东西**，上一轮的旧文件原地残留，日志还打着"已写入"。实测让 `junctions.json` 停在旧方案的 11 条记录上，成为误导后续步骤的第二真相。
   → 先算出字符串再 `-Value` 一次性写：`$json = if ($list.Count) { ConvertTo-Json -InputObject $list } else { '[]' }; Set-Content -LiteralPath $path -Value $json`。凡是"每轮都要重写同一份产物"的落盘都要这么写，并在写完回读校验一次。
7. **Bash 调用时 `$env:` 前缀被吞**：从 Bash 执行 `powershell -Command '$env:FOO=bar; ...'` 时，Bash 的 `$` 变量展开会把 `$env:` 吃掉，PowerShell 实际收到的是 `:FOO=bar`，导致环境变量设置失败且静默继续（后续步骤因缺环境变量而报错，根因难定位）。
   → **不要从 Bash 内联调用带 `$env:` 的 PowerShell 命令**。改用 `.ps1` 脚本包裹，在脚本内部用标准 PowerShell 语法 `$env:FOO = 'bar'`，然后从 Bash 调用 `powershell -File script.ps1`。

**Why:** 2026-09-18 给 Qoder 双客户端做 junction 同源化时踩中 1~3 条（第 1 条的报错行号还误导我怀疑逻辑写错，白跑两轮）；同日做 Qoder 冷数据外迁时又踩中 4、5 条——第 4 条让 robocopy 三轮静默 exit 16，第 5 条差点让"改名/建链"流水线在中途抛异常停下（那种位置最危险：一半已改名）。

**How to apply:**
- **跑 UTF-8 无 BOM 的 .ps1 必须用 `pwsh`（PowerShell 7）**：本机 `powershell`（5.1）跑 `~/.dsh/hooks/*.ps1` 会在中文行直接 `ParserError`（报错行号还指向别处）；`pwsh.exe` 在 `C:\Program Files\PowerShell\7\pwsh.exe`（不在 PATH，要用绝对路径）——2026-09-20 实跑 DSH 周检时确认。`powershell` 只用于上面那条"纯语法校验"（ASCII-only 场景）。
- 写完 `.ps1` 先做**纯语法校验**再执行，不要把运行时错误当逻辑错误：
  `powershell -NoProfile -Command "$e=$null; [void][System.Management.Automation.PSParser]::Tokenize((Get-Content -Raw './x.ps1'), [ref]$e); if($e.Count){$e|%{$_.Message}}else{'PARSE-OK'}"`
- 同一逻辑优先用 node / bash 脚本（本环境 Node 24 常驻，UTF-8 无歧义）；只在必须调用 Windows 专有 API（`New-Item -ItemType Junction`、注册表、服务）时才用 PowerShell。
- 关联：[[reference-zip-chinese-filename-compat]]（同为"Windows 工具链的中文编码坑"）、[[feedback-verify-before-diagnose]]。
