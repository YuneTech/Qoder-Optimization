---
name: reference-windows-junction-migration
description: Windows 上用 junction 把目录迁到其他盘的已实测要点：robocopy 必须带 /XJ、mklink /J 免管理员、删链接只能 rmdir、项目键名靠保持原路径
metadata:
  type: reference
---

跨盘搬家 + 原路径建 junction 映射，这套手法在本机多次用到（`~/.qoder-cn` 同源化、Qoder 主目录外迁）。以下为实测结论，不是推测：

- **`robocopy` 默认会跟随 junction**，把链接目标的内容当成普通目录复制一份到目标端。带 **`/XJ`** 才把 reparse point 排除掉（目标端连目录都不建）。对照实验：同一棵树 `/E` 复制后 `dst\lnk\file1.txt` 存在（穿透了），`/E /XJ` 后 `dst\lnk` 完全不存在（正确）。
  → 凡源树内部已有 junction，**不加 `/XJ` 就会把真源内容复制进副本**，之后两边永久分叉。
- **`mklink /J`（junction）不需要管理员权限**，普通用户即可创建，且透过链接读写正常。符号链接 `/D` 才需要 `SeCreateSymbolicLinkPrivilege` 或开发者模式。同机跨盘用 `/J` 足够。
- **删 junction 只能用 `cmd /c rmdir <链接>`**（只删链接本身）。`rd /s`、`rm -rf`、资源管理器递归删都会穿透到真源。脚本里删链接前先判 `FileAttributes.ReparsePoint`。
- **判"是不是联接、指向哪"的可失败对照（2026-09-29 实测）**：`cmd /c dir /AL "<父目录>"` 只列带重分析点的项，`<JUNCTION>` 后括号里就是目标——同盘真源显示 `[<系统盘>:\<用户目录>\...\memory]`，跨盘显示 `[D:\qoder-data\...]`，一眼分辨"合并到同一真源"与"真搬走了"。负对照组：`fsutil reparsepoint query "<实体目录>"` 报 `错误 4390：不是一个重分析点`（对 junction 返回 0xa0000003 + Name Surrogate）。**别把这两条管到 `| head` 里再读 `$?`**，管道会吞掉真实退出码。
- **Git Bash 工具对 junction 的穿透能力不一致（2026-09-23 实测）**：`ls` / `cat` / `[ -L ]`（认 junction）/ `[ -d ]` 都正常穿透，但 **`find` 不穿透 junction**——`find <junction> -type f` 返回空，链接完全正常也"看不到文件"。迁移脚本里"经原路径读文件"的验证要用 `ls -A` / `cat`，**别用 `find`**（用 find 会假失败）；cmd 原生 `dir` 判 rc 亦可（不受此限）。
- **PowerShell 的 `-Recurse` / `Get-ChildItem -Recurse` 会跟随 junction**，统计体积时重复计数甚至成环。数文件/算体积要用手动栈遍历并在遇到 reparse point 时 `continue`（自研的树体积统计脚本里 `Get-TreeStats` / `Get-LinksInTree` 即此写法）。
- **保持 C 盘原路径有效，比改路径省事得多**：工具常把路径字符串写进别处（Qoder 用工作区路径派生 `~/.qoder-cn/projects/<slug>` 记忆键；git worktree 的注册信息里是绝对 `gitdir:` 路径）。用 junction 让原路径继续解析，这些引用一律不用动。
- 改名（`Directory.Move`）会因"目录内有打开句柄"失败：迁移自己正在使用的目录，必须在**使用该目录的程序完全退出后、从外部终端**执行；改名前先枚举占用进程做守卫，比事后报错省事。

**How to apply:** 下次做"把 X 搬到别的盘并做好映射"时，照六步脚本骨架改（inventory → precopy(/XJ,/R:0) → swap(数量闸→改名留档→mklink→复现内部链接→冒烟) → verify → rollback → cleanup）。相关：[[reference-qoder-global-setup]]、[[reference-powershell-script-encoding]]、[[feedback-backup-before-modify]]。
