---
name: feedback-database-safety
description: 数据库操作安全：禁止无条件破坏性 SQL；认证失败计数到 3 即停并上报，绝不重试到账号锁定阈值
metadata:
  type: feedback
---

数据库操作遵循安全红线：
1. 禁止执行无 WHERE 条件的 UPDATE/DELETE，禁止 DROP/TRUNCATE 表（除非用户明确要求且有备份）
2. 改数据前先跑 SELECT 确认影响行数和内容，或先备份表/导出数据
3. 生产库操作尤其谨慎，DDL 变更先给用户审核

**Why:** 业界 AI Agent 安全清单的通用规则（"block DROP/DELETE SQL"）；生产库承载真实业务数据（常为多 schema），误操作影响面大且难恢复。与 [[feedback-system-stability-first]]、[[feedback-clarify-before-acting]] 一脉相承。

**How to apply:**
- 收到涉及写库的 SQL 时，先 SELECT 预览影响范围，向用户报告后再执行
- 批量修改前先建备份表（CREATE TABLE xxx_bak AS SELECT ...）或导出
- 用 WHERE 精确限定范围，优先按主键/唯一键操作
- 只读查询不受限制，可自由执行
- **认证失败计数上限（2026-10-21 生产事故，同类已发生不止一次）**：对同一目标主机+账号，认证类失败累计 **3 次立即停手并上报**，绝不逼近服务端锁定阈值（瀚高/PG 约 10 次触发 `Too many invalid attempts`，Oracle `ORA-28000`，MySQL 1045 累计触发 `max_connection_errors` 主机屏蔽）。解锁只能由 sysso/DBA 侧完成，Agent 不可自助恢复，且锁定期内每次重连都在续命。
- **从配置文件提取的凭据用前必须校验字节**：`application*.yml` / `.properties` 在 Windows 内网仓库常是 CRLF，按行截取的值带尾部 `\r`，连发的都是"错密码"。先打印长度/码点或 `replace(/\r/g,'')` 后再用；首个 `authentication failed` 出现即停手查凭据，不得继续换连接方式重试。
- 凭据正确性未确认前，不用直连（psql/jdbc/node）绕开已配置的只读 MCP 通道去试生产库。
