---
name: feedback-decision-options
description: 需要用户决定时给真实备选与推荐项；不凑选项、不重复索取同范围授权
metadata:
  type: feedback
---

需要用户拍板时讲清收益、代价与推荐；能自行选择合理默认值的内部技术问题不占用裁决轮。

**Why:** 用户希望知情决策，又不希望任务因常规实现选择停摆；沉默不能被当作批准。

**How to apply:** 使用弹窗给真实可行备选，不为了满足数量添加无意义选项。同范围明确执行选择有效，不重问；取消、未选或仅确认方案不授权实施。平台额外审批保留；当前审阅报告交付即完成，不把待批准整改当成未完成审阅。

相关：[[feedback-pop-decision-dialog-not-prose]]。
