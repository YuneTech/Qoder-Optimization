---
name: tooling-docker-cn-mirror-ci-repro
description: 本机在 Docker 里复现 Linux CI 那一遍的可用镜像源与四个实测坑：docker.io 被 hosts 污染必须走 daocloud 前缀、Debian 的 maven 包依赖树巨大要改用 TUNA tarball、git archive 会按 .gitattributes 转换行尾所以不是忠实的全新检出、测试硬连 127.0.0.1 时要用 --network container: 共享命名空间
metadata:
  type: reference
---

# 本机用 Docker 复现"Linux 全新检出"那一遍（2026-09-21 实测跑通）

**目的**：CI 跑在 `ubuntu-latest`，而本机是 Windows + `core.autocrlf=true` ⇒ 有一类缺陷只在"别人的机器"上现形。
本轮靠这套办法在推送前抓到 3 条真实问题（行尾政策漏 767 个文件、两道门在普通 Linux 上假绿/假红、一条 Java 断言红着活了一年）。

## 1. 镜像源：`docker.io` 直连必失败，加前缀就通

- 症状：`docker pull node:20` → `dialing registry-1.docker.io:443 ... connectex`，且解析到的 IP 是 **`157.240.1.9`**
  （Facebook 段）——**根因是本机加速器的 hosts 块污染了 docker 域名**，不是 Docker Desktop 坏了（它其实正常运行）。
- 可用：**`docker.m.daocloud.io/library/<镜像>`**（实测 `node:20`、`mongo:7` 都拉得动）。
  `registry.cn-hangzhou.aliyuncs.com/library/node` 报 `pull access denied`（不可用）；
  `docker.m.daocloud.io/v2/` 返回 **401 是"可达"的正确信号**（registry 握手要认证），别把它读成不通。
- 先测可达性再动手：`curl -o /dev/null -w "%{http_code}" <url>`，一条命令省掉二十分钟瞎试。

## 2. 容器里的 JDK/Maven：别装 Debian 的 `maven` 包

- `apt-get install maven` 会拖进几十包 Java 库，本机 **20 分钟没跑完**；改用 tarball 解包（几十秒）：
  `https://mirrors.tuna.tsinghua.edu.cn/Adoptium/17/jdk/x64/linux/OpenJDK17U-jdk_x64_linux_hotspot_<ver>.tar.gz`、
  `https://mirrors.tuna.tsinghua.edu.cn/apache/maven/maven-3/<ver>/binaries/apache-maven-<ver>-bin.tar.gz`
  （版本号要先抓目录列表，猜的 `3.9.11` 直接 404）。
- Maven 依赖走阿里云：`~/.m2/settings.xml` 里 `<mirror><mirrorOf>central</mirrorOf><url>https://maven.aliyun.com/repository/public</url></mirror>`。
  **该站根路径 GET 返回 404 是正常的**，可达性要用真实 artifact 路径判（实测 `.pom` 返回 200）。
- Python 依赖（本项目图标门要 Pillow）：`apt-get install -y python3-pil` 即可，`pip3` 在 node 镜像里**没有**。

## 3. `git archive` 不是"全新检出"的忠实副本（行尾陷阱）

- 用 `git archive HEAD | docker exec -i <c> tar -x` 做"干净检出"是对的（能测到工作树之外的东西），
  但 **`git archive` 会按 `.gitattributes` / `core.autocrlf` 应用文本转换**：
  实测 archive 出来的容器里有 19 个 `.js` 带 CRLF，而 `git show HEAD:<file>` 的 blob 是**纯 LF**；
  CI 的 `actions/checkout` 在 Linux 上 `autocrlf=false` ⇒ 那边是 LF。
- **判"哪些文件在别的机器上会变样"要用 `git ls-files --eol`**（列 `i/lf` / `w/crlf` / `attr/…` 三列），
  不要拿 archive 的读数当结论——否则会把"我的归档方式"误诊成"产品的缺陷"。
  反过来这条也救了一次：正是 archive 暴露出 `.gitattributes` 的 `eol=lf` 是**按扩展名点名的清单**、漏了一大片。

## 3.5 行尾政策的正确修法：默认全 LF，不要按扩展名点名

- 症状：`.gitattributes` 写着"仓库内一律 LF、检出也强制 LF"，但实现是**按扩展名点名的清单**
  （json/ts/java/sh/md/meta/mjs）⇒ 清单外的一切跟着 `core.autocrlf` 走，实测漏了 **767 个文本文件**
  （门脚本自己的 `.js`、`art-src/*.py`、`ci.yml`、每个 `pom.xml`、`Makefile`，连 `.gitattributes` 自己）。
- 正解：`* text=auto eol=lf` 一条兜全部，再给真资产显式 `-text`（png/ogg/swf/ttf/ai）。
- **加规则前先查"同扩展名里有没有被 git 判成二进制的文件"**：本仓库有 **2 个 `.txt` 是 `i/-text`**，
  一旦写 `*.txt text eol=lf` 就会**静默改二进制**——所以 `*.txt` 故意不加，交给 `text=auto` 自己认。
- 判据用 `git ls-files --eol` 的三列（`i/lf|i/mixed` 是文本、`i/-text` 是二进制、`i/none` 没有换行可错），
  配一条门盯"文本 blob 必须有 `eol=lf`"，否则这张清单还会再漏。
  改完必须核副作用：`git status --porcelain` 应只剩你改的那几个文件（**不该出现 767 个"已修改"**）。

## 4. 测试硬连 `127.0.0.1:<port>` 时，端口映射不够

- 被测代码连的是 `localhost:27017`（MongoDB），而它在**另一个容器**里 ⇒ `-p` 映射到宿主机没用。
- 正解：**共享网络命名空间** —— `docker run -d --name mongo --network container:<测试容器> mongo:7`，
  这样测试容器里的 `127.0.0.1:27017` 就是它。宿主机上跑测试时才用 `-p 27017:27017`。

## 5. 容器里 apt 的三个坑（本轮全踩）

1. **两个 `apt-get` 并发会互锁**：第一次被外层 `timeout` 杀掉后进程还在容器里活着，第二次会卡在锁上；
   `rm -f /var/lib/apt/lists/lock` **不释放 flock**，反而让状态更难判断。
2. **外层 `timeout` 会把 apt 打断在下载阶段**：日志只剩 `Get:19 ...`，而 `command -v mvn` 才是真相 ——
   通知里的 "exit 0" 属于整条命令链（见 tooling-background-task-exit-code）。
3. 长安装一律 `run_in_background` 且**在命令里显式写退出码**（`... ; echo "APT_EXIT=$?" >> log`），判完成只认这一行。
   收尾：`dpkg --configure -a` + `pkill -f "apt-get install"` 再重装一次干净的。

## 6. 清理

自己起的临时容器与挂端口都要收掉：`docker rm -f <name>`（镜像留着，别重拉）。
**别停用户自己的容器**（本机有 `polardb-pg` 在跑）。

相关：`github-access-setup`（hosts 污染的根因与 curl 修复）、`windows-wsl2-docker-setup`、
tooling-playwright-probe-patterns（同一轮里"构建与探针不能并行"的同族坑）。
