#!/bin/bash
# ============================================================
# Qoder 全局记忆导入脚本
# 用法: bash import-memory.sh <导出的tar.gz文件>
# 功能: 解压并恢复记忆文件到 ~/.qoder/memory/
# ============================================================

set -euo pipefail

if [ $# -lt 1 ]; then
  echo "用法: bash import-memory.sh <导出的tar.gz文件>"
  echo ""
  echo "示例:"
  echo "  bash import-memory.sh qoder-memory-export-20260916-181859.tar.gz"
  exit 1
fi

ARCHIVE="$1"
MEMORY_DIR="$HOME/.qoder/memory"

if [ ! -f "$ARCHIVE" ]; then
  echo "错误: 文件不存在: $ARCHIVE"
  exit 1
fi

# 创建记忆目录（如不存在）
mkdir -p "$MEMORY_DIR"

# 创建备份（如果已有记忆文件）
if [ -f "$MEMORY_DIR/MEMORY.md" ]; then
  BACKUP_DIR="$HOME/.qoder/tmp/memory-import-backup-$(date +%Y%m%d%H%M%S)"
  mkdir -p "$BACKUP_DIR"
  cp "$MEMORY_DIR"/*.md "$BACKUP_DIR/" 2>/dev/null || true
  echo "已备份现有记忆到: $BACKUP_DIR"
fi

# 解压到临时目录
STAGING_DIR=$(mktemp -d)
tar -xzf "$ARCHIVE" -C "$STAGING_DIR"

# 找到解压后的目录
EXTRACTED_DIR=$(find "$STAGING_DIR" -maxdepth 1 -type d -name "qoder-memory-export-*" | head -1)
if [ -z "$EXTRACTED_DIR" ]; then
  echo "错误: 解压后未找到 qoder-memory-export-* 目录"
  rm -rf "$STAGING_DIR"
  exit 1
fi

# 复制记忆文件
COPIED=0
for f in "$EXTRACTED_DIR"/*.md; do
  [ -f "$f" ] || continue
  filename=$(basename "$f")

  # 跳过模板说明文件
  if [ "$filename" = "CREDENTIALS-TEMPLATE.md" ]; then
    echo "  跳过(模板说明): $filename"
    continue
  fi

  cp "$f" "$MEMORY_DIR/"
  COPIED=$((COPIED + 1))
done

# 复制脚本（如果存在）
if [ -d "$EXTRACTED_DIR/scripts" ]; then
  SCRIPTS_DIR="$HOME/.qoder/scripts"
  mkdir -p "$SCRIPTS_DIR"
  for s in "$EXTRACTED_DIR/scripts"/*.sh; do
    [ -f "$s" ] && cp "$s" "$SCRIPTS_DIR/"
  done
  echo "已恢复脚本到: $SCRIPTS_DIR"
fi

# 清理
rm -rf "$STAGING_DIR"

echo ""
echo "=== 导入完成 ==="
echo "已导入: ${COPIED} 个文件到 $MEMORY_DIR"
echo ""
echo "后续步骤:"
echo "  1. 检查 MEMORY.md 索引是否完整"
echo "  2. 手动创建凭据文件（参考 CREDENTIALS-TEMPLATE.md 格式）"
echo "     - reference-gitlab-credentials.md（示例）"
echo "     - reference-server-credentials.md（示例）"
echo "     - reference-database-credentials.md（示例）"
